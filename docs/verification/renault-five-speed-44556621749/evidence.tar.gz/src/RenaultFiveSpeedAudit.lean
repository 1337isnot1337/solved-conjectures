import Conjectures.HaralambisCounting
import Conjectures.HaralambisDefects
import Conjectures.HaralambisDensity
import Conjectures.HaralambisFaces
import Conjectures.HaralambisIntervals
import Conjectures.HaralambisOrientation
import Conjectures.HaralambisPairSum
import Conjectures.HaralambisPeriods
import Conjectures.HaralambisTheorem
import Conjectures.Loneliness
import Conjectures.LonelinessCertificate
import Conjectures.LonelinessCoalescence
import Conjectures.LonelinessCoalescenceAvoiding
import Conjectures.LonelinessCoalescenceValue
import Conjectures.LonelinessContinuity
import Conjectures.LonelinessCoordinateClasses
import Conjectures.LonelinessCoordinateSubspace
import Conjectures.LonelinessCriticalBase
import Conjectures.LonelinessCriticalFamilies
import Conjectures.LonelinessCriticalSecond
import Conjectures.LonelinessExamples
import Conjectures.LonelinessFiveFamily
import Conjectures.LonelinessFiveSpeedBound
import Conjectures.LonelinessFourSpeedCertificate
import Conjectures.LonelinessFourSpeedCertificate17
import Conjectures.LonelinessFourSpeedCertificate29
import Conjectures.LonelinessFourSpeedCertificate31
import Conjectures.LonelinessFourSpeedCertificate37
import Conjectures.LonelinessFourSpeedCertificate41
import Conjectures.LonelinessFourSpeedCertificate43
import Conjectures.LonelinessFourSpeedCertificate47
import Conjectures.LonelinessFourSpeedCertificate53
import Conjectures.LonelinessFourSpeedCertificate59
import Conjectures.LonelinessFourSpeedCertificate61
import Conjectures.LonelinessFourSpeedCertificateAll
import Conjectures.LonelinessFourSpeedCertificateChunks
import Conjectures.LonelinessFourSpeedClassification
import Conjectures.LonelinessFourSpeedClassificationFinite
import Conjectures.LonelinessFourSpeedCutoff
import Conjectures.LonelinessFourSpeedEnumeration
import Conjectures.LonelinessFourSpeedFastEnumeration
import Conjectures.LonelinessFourSpeedFinite
import Conjectures.LonelinessFourSpeedFoldedGeometry
import Conjectures.LonelinessFourSpeedGap
import Conjectures.LonelinessFourSpeedGeometry
import Conjectures.LonelinessFourSpeedLift17
import Conjectures.LonelinessFourSpeedLift29
import Conjectures.LonelinessFourSpeedLift31
import Conjectures.LonelinessFourSpeedLift37
import Conjectures.LonelinessFourSpeedLift41
import Conjectures.LonelinessFourSpeedLift43
import Conjectures.LonelinessFourSpeedLift47
import Conjectures.LonelinessFourSpeedLift53
import Conjectures.LonelinessFourSpeedLift59
import Conjectures.LonelinessFourSpeedLift61
import Conjectures.LonelinessFourSpeedLiftDirections
import Conjectures.LonelinessFourSpeedLiftSound
import Conjectures.LonelinessIntegerDirection
import Conjectures.LonelinessMax
import Conjectures.LonelinessModularDirections
import Conjectures.LonelinessModularFoldedSearch
import Conjectures.LonelinessModularLift
import Conjectures.LonelinessModularNormalize
import Conjectures.LonelinessModularPrimes
import Conjectures.LonelinessModularRationalWitness
import Conjectures.LonelinessModularSearch
import Conjectures.LonelinessModularShortVector
import Conjectures.LonelinessModularWitness
import Conjectures.LonelinessNormalization
import Conjectures.LonelinessPacking
import Conjectures.LonelinessPackingLower
import Conjectures.LonelinessPairBridge
import Conjectures.LonelinessPigeonhole
import Conjectures.LonelinessPigeonholePlane
import Conjectures.LonelinessPlaneDirections
import Conjectures.LonelinessPlaneGap
import Conjectures.LonelinessProductFamily
import Conjectures.LonelinessRational
import Conjectures.LonelinessRationalSubspace
import Conjectures.LonelinessRenaultAffine
import Conjectures.LonelinessRenaultAssembly
import Conjectures.LonelinessRenaultFiveSpeed
import Conjectures.LonelinessRenaultGcdOrbit
import Conjectures.LonelinessRenaultMaximizer
import Conjectures.LonelinessRenaultNormalization
import Conjectures.LonelinessRenaultOrdering
import Conjectures.LonelinessRenaultParityCases
import Conjectures.LonelinessRenaultPhaseCells
import Conjectures.LonelinessRenaultPhaseCertificates
import Conjectures.LonelinessRenaultPreliminaries
import Conjectures.LonelinessRenaultRationalOrbit
import Conjectures.LonelinessRenaultReindex
import Conjectures.LonelinessRenaultSmallPhases
import Conjectures.LonelinessRenaultThirdObstructions
import Conjectures.LonelinessRenaultThreeEven
import Conjectures.LonelinessRenaultTwoMultiples
import Conjectures.LonelinessRenaultTwoMultiplesCase
import Conjectures.LonelinessRenaultTwoMultiplesFinal
import Conjectures.LonelinessRenaultTwoMultiplesPhase
import Conjectures.LonelinessSmallRunner
import Conjectures.LonelinessSubspaceDensity
import Conjectures.LonelinessSubspaceExtension
import Conjectures.LonelinessTwoDirections
import Conjectures.NonmixedGapDensity
import Conjectures.NonmixedGapPeriodic
import Conjectures.NonmixedGapResidues
import Lean.Util.CollectAxioms
import Lean.PrivateName
import Lean.Elab.Command
import Lean.Data.Json

set_option maxRecDepth 100000
set_option maxHeartbeats 0

open Lean Elab Command in
run_cmd do
  let expectedModules : Array String := #["Conjectures.HaralambisCounting", "Conjectures.HaralambisDefects", "Conjectures.HaralambisDensity", "Conjectures.HaralambisFaces", "Conjectures.HaralambisIntervals", "Conjectures.HaralambisOrientation", "Conjectures.HaralambisPairSum", "Conjectures.HaralambisPeriods", "Conjectures.HaralambisTheorem", "Conjectures.Loneliness", "Conjectures.LonelinessCertificate", "Conjectures.LonelinessCoalescence", "Conjectures.LonelinessCoalescenceAvoiding", "Conjectures.LonelinessCoalescenceValue", "Conjectures.LonelinessContinuity", "Conjectures.LonelinessCoordinateClasses", "Conjectures.LonelinessCoordinateSubspace", "Conjectures.LonelinessCriticalBase", "Conjectures.LonelinessCriticalFamilies", "Conjectures.LonelinessCriticalSecond", "Conjectures.LonelinessExamples", "Conjectures.LonelinessFiveFamily", "Conjectures.LonelinessFiveSpeedBound", "Conjectures.LonelinessFourSpeedCertificate", "Conjectures.LonelinessFourSpeedCertificate17", "Conjectures.LonelinessFourSpeedCertificate29", "Conjectures.LonelinessFourSpeedCertificate31", "Conjectures.LonelinessFourSpeedCertificate37", "Conjectures.LonelinessFourSpeedCertificate41", "Conjectures.LonelinessFourSpeedCertificate43", "Conjectures.LonelinessFourSpeedCertificate47", "Conjectures.LonelinessFourSpeedCertificate53", "Conjectures.LonelinessFourSpeedCertificate59", "Conjectures.LonelinessFourSpeedCertificate61", "Conjectures.LonelinessFourSpeedCertificateAll", "Conjectures.LonelinessFourSpeedCertificateChunks", "Conjectures.LonelinessFourSpeedClassification", "Conjectures.LonelinessFourSpeedClassificationFinite", "Conjectures.LonelinessFourSpeedCutoff", "Conjectures.LonelinessFourSpeedEnumeration", "Conjectures.LonelinessFourSpeedFastEnumeration", "Conjectures.LonelinessFourSpeedFinite", "Conjectures.LonelinessFourSpeedFoldedGeometry", "Conjectures.LonelinessFourSpeedGap", "Conjectures.LonelinessFourSpeedGeometry", "Conjectures.LonelinessFourSpeedLift17", "Conjectures.LonelinessFourSpeedLift29", "Conjectures.LonelinessFourSpeedLift31", "Conjectures.LonelinessFourSpeedLift37", "Conjectures.LonelinessFourSpeedLift41", "Conjectures.LonelinessFourSpeedLift43", "Conjectures.LonelinessFourSpeedLift47", "Conjectures.LonelinessFourSpeedLift53", "Conjectures.LonelinessFourSpeedLift59", "Conjectures.LonelinessFourSpeedLift61", "Conjectures.LonelinessFourSpeedLiftDirections", "Conjectures.LonelinessFourSpeedLiftSound", "Conjectures.LonelinessIntegerDirection", "Conjectures.LonelinessMax", "Conjectures.LonelinessModularDirections", "Conjectures.LonelinessModularFoldedSearch", "Conjectures.LonelinessModularLift", "Conjectures.LonelinessModularNormalize", "Conjectures.LonelinessModularPrimes", "Conjectures.LonelinessModularRationalWitness", "Conjectures.LonelinessModularSearch", "Conjectures.LonelinessModularShortVector", "Conjectures.LonelinessModularWitness", "Conjectures.LonelinessNormalization", "Conjectures.LonelinessPacking", "Conjectures.LonelinessPackingLower", "Conjectures.LonelinessPairBridge", "Conjectures.LonelinessPigeonhole", "Conjectures.LonelinessPigeonholePlane", "Conjectures.LonelinessPlaneDirections", "Conjectures.LonelinessPlaneGap", "Conjectures.LonelinessProductFamily", "Conjectures.LonelinessRational", "Conjectures.LonelinessRationalSubspace", "Conjectures.LonelinessRenaultAffine", "Conjectures.LonelinessRenaultAssembly", "Conjectures.LonelinessRenaultFiveSpeed", "Conjectures.LonelinessRenaultGcdOrbit", "Conjectures.LonelinessRenaultMaximizer", "Conjectures.LonelinessRenaultNormalization", "Conjectures.LonelinessRenaultOrdering", "Conjectures.LonelinessRenaultParityCases", "Conjectures.LonelinessRenaultPhaseCells", "Conjectures.LonelinessRenaultPhaseCertificates", "Conjectures.LonelinessRenaultPreliminaries", "Conjectures.LonelinessRenaultRationalOrbit", "Conjectures.LonelinessRenaultReindex", "Conjectures.LonelinessRenaultSmallPhases", "Conjectures.LonelinessRenaultThirdObstructions", "Conjectures.LonelinessRenaultThreeEven", "Conjectures.LonelinessRenaultTwoMultiples", "Conjectures.LonelinessRenaultTwoMultiplesCase", "Conjectures.LonelinessRenaultTwoMultiplesFinal", "Conjectures.LonelinessRenaultTwoMultiplesPhase", "Conjectures.LonelinessSmallRunner", "Conjectures.LonelinessSubspaceDensity", "Conjectures.LonelinessSubspaceExtension", "Conjectures.LonelinessTwoDirections", "Conjectures.NonmixedGapDensity", "Conjectures.NonmixedGapPeriodic", "Conjectures.NonmixedGapResidues"]
  let required : Array Name := #[`Loneliness.Renault.PhaseAction.good_fract_iff, `Loneliness.Renault.PhaseCover.check_sound, `Loneliness.Renault.allSafe_of_residue_cases, `Loneliness.Renault.allSafe_reindex_iff, `Loneliness.Renault.bounded_list_value_lower_of_primitive, `Loneliness.Renault.card_filter_equiv, `Loneliness.Renault.caseEquiv_zero, `Loneliness.Renault.caseOrder_bijective, `Loneliness.Renault.caseOrder_zero, `Loneliness.Renault.distance_add_half, `Loneliness.Renault.distance_div_nat_eq_zero_iff, `Loneliness.Renault.distance_eq_min_fract, `Loneliness.Renault.distance_mul_fract_eq, `Loneliness.Renault.distance_nat_mul_distance, `Loneliness.Renault.distance_of_unit_interval, `Loneliness.Renault.distance_rational_shift_of_dvd, `Loneliness.Renault.distance_strict_of_cell, `Loneliness.Renault.distance_third_shift_of_dvd, `Loneliness.Renault.distance_time_add_of_dvd, `Loneliness.Renault.distance_time_affine_six, `Loneliness.Renault.divisibility_card_bounds, `Loneliness.Renault.divisibility_card_le_three, `Loneliness.Renault.divisibility_card_pos, `Loneliness.Renault.double_half_strict_of_outer, `Loneliness.Renault.endpoint_runner_third_shift_safe, `Loneliness.Renault.endpoint_third_shift_safe, `Loneliness.Renault.exists_allSafe_of_fast, `Loneliness.Renault.exists_allSafe_of_first_two_multiples, `Loneliness.Renault.exists_allSafe_of_four_multiples, `Loneliness.Renault.exists_allSafe_of_three_multiples, `Loneliness.Renault.exists_allSafe_of_two_multiples, `Loneliness.Renault.exists_allSafe_reindex_iff, `Loneliness.Renault.exists_caseOrder, `Loneliness.Renault.exists_constrained_maximum, `Loneliness.Renault.exists_four_safe_except, `Loneliness.Renault.exists_four_safe_on, `Loneliness.Renault.exists_maximizer_with_upper_boundary, `Loneliness.Renault.exists_nearby_safe, `Loneliness.Renault.exists_phase_fiber_maximum, `Loneliness.Renault.exists_positive_feasible, `Loneliness.Renault.exists_positive_maximizer, `Loneliness.Renault.exists_reindex_two, `Loneliness.Renault.exists_set_bit, `Loneliness.Renault.exists_small_multiplier_unsafe, `Loneliness.Renault.exists_strict_safe_except, `Loneliness.Renault.exists_third_shift_of_at_most_two, `Loneliness.Renault.exists_third_shift_of_endpoint, `Loneliness.Renault.exists_third_shift_of_three_close, `Loneliness.Renault.exists_third_shift_of_two_unsafe, `Loneliness.Renault.fiveSafe_iff_allSafe, `Loneliness.Renault.five_list_value_lower_of_primitive, `Loneliness.Renault.five_speed_bound_of_four, `Loneliness.Renault.five_speed_common_time, `Loneliness.Renault.five_speed_common_time_of_four, `Loneliness.Renault.five_speed_lonelyRunnerBound, `Loneliness.Renault.foldr_gcd_ofFn_reindex, `Loneliness.Renault.fract_int_mul_fract, `Loneliness.Renault.fract_nat_mul_fract, `Loneliness.Renault.fract_time_add_of_dvd, `Loneliness.Renault.fract_time_affine_six, `Loneliness.Renault.gcd_orbit_point, `Loneliness.Renault.maximizer_has_upper_boundary, `Loneliness.Renault.no_double_middle_distance, `Loneliness.Renault.odd_divides_of_middle_condition, `Loneliness.Renault.ordered_phase_band, `Loneliness.Renault.ordered_phase_fiber_zero, `Loneliness.Renault.phaseActionCheck_sound, `Loneliness.Renault.phaseMaskCheck_sound, `Loneliness.Renault.phaseTripleCheck_sound, `Loneliness.Renault.phase_fiber_affine_six, `Loneliness.Renault.phase_fiber_multiplier_distance, `Loneliness.Renault.phase_fiber_odd_multiple, `Loneliness.Renault.phase_fiber_zero_divisibility, `Loneliness.Renault.phase_lemma_5_1, `Loneliness.Renault.phase_lemma_5_2, `Loneliness.Renault.phase_lemma_5_3, `Loneliness.Renault.phase_lemma_6_1, `Loneliness.Renault.phase_lemma_6_2, `Loneliness.Renault.phase_lemma_6_3, `Loneliness.Renault.phase_lemma_6_4, `Loneliness.Renault.phase_lemma_6_5, `Loneliness.Renault.phase_three_covers, `Loneliness.Renault.primitive_five_safe_time, `Loneliness.Renault.primitive_five_safe_time_of_four, `Loneliness.Renault.primitive_reindex_iff, `Loneliness.Renault.runner_bound_five_of_primitive, `Loneliness.Renault.small_multiple_distance_gt, `Loneliness.Renault.third_shift_safe_of_initial_le, `Loneliness.Renault.third_unsafe_unique, `Loneliness.Renault.three_even_safe_time, `Loneliness.Renault.three_even_safe_time_of_signed_residues, `Loneliness.Renault.three_even_shift_phase, `Loneliness.Renault.three_five_distance_band, `Loneliness.Renault.two_even_safe_time, `Loneliness.Renault.two_even_safe_time_of_phase_lemmas, `Loneliness.Renault.two_multiple_final_times, `Loneliness.Renault.two_multiple_forced_divisibility, `Loneliness.Renault.two_odd_phase_improvement, `Loneliness.Renault.unique_even_safe_time, `Loneliness.Renault.unique_even_safe_time_of_phase_lemmas]
  let legacyPrefixes : Array String := #["Loneliness."]
  let allowed : Array Name := #[`propext, `Classical.choice, `Quot.sound]
  let env ← getEnv
  if env.header.isModule then
    throwError "All-owned audit must use legacy private-import mode"
  unless env.header.modules.size == env.header.moduleData.size do
    throwError "Imported module/data inventory size mismatch"
  let mut rawNames : NameSet := {}
  let mut seenModules : Array String := #[]
  for h : idx in [0:env.header.modules.size] do
    let mod := env.header.modules[idx]
    let moduleName := mod.module.toString
    let isProject := moduleName == "Solitaire" || moduleName.startsWith "Solitaire." ||
      moduleName == "Conjectures" || moduleName.startsWith "Conjectures."
    unless !isProject || expectedModules.contains moduleName do
      throwError "Unregistered project module in audit: {moduleName}"
    if expectedModules.contains moduleName then
      unless mod.hasData && mod.importAll do
        throwError "Project module lacks complete private data: {moduleName}"
      let data := env.header.moduleData[idx]!
      unless data.constNames == data.constants.map (·.name) do
        throwError "Serialized declaration names differ from their constants: {moduleName}"
      seenModules := seenModules.push moduleName
      let mut privateCount := 0
      for name in data.constNames do
        unless (env.find? name).isSome do
          throwError "Serialized project declaration is invisible: {moduleName}: {name}"
        rawNames := rawNames.insert name
        if (privateToUserName? name).isSome then
          privateCount := privateCount + 1
      let record := Json.mkObj [
        ("tag", toJson "module"), ("module", toJson moduleName),
        ("modern", toJson data.isModule), ("import_all", toJson mod.importAll),
        ("has_data", toJson mod.hasData),
        ("names", toJson (data.constNames.map (·.toString))),
        ("private_count", toJson privateCount)]
      logInfo m!"ALL-OWNED-JSON {record.compress}"
  unless seenModules.size == expectedModules.size &&
      expectedModules.all seenModules.contains do
    throwError "Incomplete exact project module inventory"
  let mut audited : NameSet := {}
  let mut declarations := 0
  let mut theorems := 0
  let mut privateDeclarations := 0
  for (name, info) in env.constants.toList do
    let owner := match env.getModuleIdxFor? name |>.bind (env.header.modules[·]?) with
      | some mod => mod.module.toString
      | none => ""
    let userName := privateToUserName name
    let byModule := expectedModules.contains owner
    let bySerialized := rawNames.contains name
    let byLegacy := legacyPrefixes.any (fun p => userName.toString.startsWith p)
    if byModule || bySerialized || byLegacy then
      declarations := declarations + 1
      audited := audited.insert name
      let kind := match info with
        | .axiomInfo _ => "axiom"
        | .defnInfo _ => "definition"
        | .thmInfo _ => "theorem"
        | .opaqueInfo _ => "opaque"
        | .quotInfo _ => "quotient"
        | .ctorInfo _ => "constructor"
        | .recInfo _ => "recursor"
        | .inductInfo _ => "inductive"
      if info.isTheorem then
        theorems := theorems + 1
      let privateName := privateToUserName? name
      if privateName.isSome then
        privateDeclarations := privateDeclarations + 1
      if let .axiomInfo _ := info then
        unless allowed.contains name do
          throwError "Unapproved project axiom {name}"
      let axioms ← collectAxioms name
      for axiomName in axioms do
        unless allowed.contains axiomName do
          throwError "Unapproved axiom {axiomName} in {name}"
      let record := Json.mkObj [
        ("tag", toJson "declaration"), ("name", toJson name.toString),
        ("owner", toJson owner), ("kind", toJson kind),
        ("private_user_name", toJson (privateName.map (·.toString))),
        ("by_module", toJson byModule), ("by_serialized", toJson bySerialized),
        ("by_legacy_prefix", toJson byLegacy),
        ("axioms", toJson (axioms.map (·.toString)))]
      logInfo m!"ALL-OWNED-JSON {record.compress}"
  for name in rawNames.toArray do
    unless audited.contains name do
      throwError "Serialized project declaration escaped the audit: {name}"
  for name in required do
    let _ ← getConstInfo name
    unless audited.contains name do
      throwError "Required declaration is outside audited ownership: {name}"
    let record := Json.mkObj [("tag", toJson "required"), ("name", toJson name.toString)]
    logInfo m!"ALL-OWNED-JSON {record.compress}"
  let record := Json.mkObj [
    ("tag", toJson "passed"), ("modules", toJson seenModules.size),
    ("declarations", toJson declarations), ("theorems", toJson theorems),
    ("private_declarations", toJson privateDeclarations),
    ("raw_declarations", toJson rawNames.toArray.size),
    ("required", toJson required.size), ("allowed_axioms", toJson (allowed.map (·.toString)))]
  logInfo m!"ALL-OWNED-JSON {record.compress}"
