import Conjectures.Loneliness
import Conjectures.LonelinessContinuity
import Conjectures.LonelinessCriticalBase
import Conjectures.LonelinessCriticalFamilies
import Conjectures.LonelinessCriticalSecond
import Conjectures.LonelinessFiveFamily
import Conjectures.LonelinessNormalization
import Conjectures.LonelinessRenaultAffine
import Conjectures.LonelinessRenaultGcdOrbit
import Conjectures.LonelinessRenaultMaximizer
import Conjectures.LonelinessRenaultPhaseCells
import Conjectures.LonelinessRenaultPhaseCertificates
import Conjectures.LonelinessRenaultPreliminaries
import Conjectures.LonelinessRenaultReindex
import Conjectures.LonelinessRenaultSmallPhases
import Conjectures.LonelinessRenaultThirdObstructions
import Conjectures.LonelinessRenaultTwoMultiples
import Conjectures.LonelinessRenaultTwoMultiplesPhase
import Lean.Util.CollectAxioms
import Lean.PrivateName
import Lean.Elab.Command
import Lean.Data.Json

set_option maxRecDepth 100000
set_option maxHeartbeats 0

open Lean Elab Command in
run_cmd do
  let expectedModules : Array String := #["Conjectures.Loneliness", "Conjectures.LonelinessContinuity", "Conjectures.LonelinessCriticalBase", "Conjectures.LonelinessCriticalFamilies", "Conjectures.LonelinessCriticalSecond", "Conjectures.LonelinessFiveFamily", "Conjectures.LonelinessNormalization", "Conjectures.LonelinessRenaultAffine", "Conjectures.LonelinessRenaultGcdOrbit", "Conjectures.LonelinessRenaultMaximizer", "Conjectures.LonelinessRenaultPhaseCells", "Conjectures.LonelinessRenaultPhaseCertificates", "Conjectures.LonelinessRenaultPreliminaries", "Conjectures.LonelinessRenaultReindex", "Conjectures.LonelinessRenaultSmallPhases", "Conjectures.LonelinessRenaultThirdObstructions", "Conjectures.LonelinessRenaultTwoMultiples", "Conjectures.LonelinessRenaultTwoMultiplesPhase"]
  let required : Array Name := #[`Loneliness.Renault.PhaseAction.good_fract_iff, `Loneliness.Renault.PhaseCover.check_sound, `Loneliness.Renault.allSafe_reindex_iff, `Loneliness.Renault.card_filter_equiv, `Loneliness.Renault.distance_add_half, `Loneliness.Renault.distance_div_nat_eq_zero_iff, `Loneliness.Renault.distance_eq_min_fract, `Loneliness.Renault.distance_mul_fract_eq, `Loneliness.Renault.distance_nat_mul_distance, `Loneliness.Renault.distance_of_unit_interval, `Loneliness.Renault.distance_rational_shift_of_dvd, `Loneliness.Renault.distance_strict_of_cell, `Loneliness.Renault.distance_third_shift_of_dvd, `Loneliness.Renault.distance_time_add_of_dvd, `Loneliness.Renault.distance_time_affine_six, `Loneliness.Renault.double_half_strict_of_outer, `Loneliness.Renault.endpoint_runner_third_shift_safe, `Loneliness.Renault.endpoint_third_shift_safe, `Loneliness.Renault.exists_allSafe_reindex_iff, `Loneliness.Renault.exists_constrained_maximum, `Loneliness.Renault.exists_maximizer_with_upper_boundary, `Loneliness.Renault.exists_nearby_safe, `Loneliness.Renault.exists_phase_fiber_maximum, `Loneliness.Renault.exists_positive_feasible, `Loneliness.Renault.exists_positive_maximizer, `Loneliness.Renault.exists_reindex_two, `Loneliness.Renault.exists_set_bit, `Loneliness.Renault.exists_small_multiplier_unsafe, `Loneliness.Renault.exists_third_shift_of_at_most_two, `Loneliness.Renault.exists_third_shift_of_endpoint, `Loneliness.Renault.exists_third_shift_of_three_close, `Loneliness.Renault.exists_third_shift_of_two_unsafe, `Loneliness.Renault.foldr_gcd_ofFn_reindex, `Loneliness.Renault.fract_int_mul_fract, `Loneliness.Renault.fract_nat_mul_fract, `Loneliness.Renault.fract_time_add_of_dvd, `Loneliness.Renault.fract_time_affine_six, `Loneliness.Renault.gcd_orbit_point, `Loneliness.Renault.maximizer_has_upper_boundary, `Loneliness.Renault.ordered_phase_band, `Loneliness.Renault.phaseActionCheck_sound, `Loneliness.Renault.phaseMaskCheck_sound, `Loneliness.Renault.phaseTripleCheck_sound, `Loneliness.Renault.phase_fiber_affine_six, `Loneliness.Renault.phase_fiber_multiplier_distance, `Loneliness.Renault.phase_fiber_odd_multiple, `Loneliness.Renault.phase_fiber_zero_divisibility, `Loneliness.Renault.phase_lemma_5_1, `Loneliness.Renault.phase_lemma_5_2, `Loneliness.Renault.phase_lemma_5_3, `Loneliness.Renault.phase_lemma_6_1, `Loneliness.Renault.phase_lemma_6_2, `Loneliness.Renault.phase_lemma_6_3, `Loneliness.Renault.phase_lemma_6_4, `Loneliness.Renault.phase_lemma_6_5, `Loneliness.Renault.phase_three_covers, `Loneliness.Renault.primitive_reindex_iff, `Loneliness.Renault.small_multiple_distance_gt, `Loneliness.Renault.third_shift_safe_of_initial_le, `Loneliness.Renault.third_unsafe_unique, `Loneliness.Renault.three_even_shift_phase, `Loneliness.Renault.three_five_distance_band, `Loneliness.Renault.two_multiple_final_times, `Loneliness.Renault.two_odd_phase_improvement]
  let legacyPrefixes : Array String := #["Loneliness."]
  let allowed : Array Name := #[`propext, `Classical.choice, `Quot.sound]
  let env ← getEnv
  if env.header.isModule then
    throwError "All-owned audit must use legacy private-import mode"
  unless env.header.modules.size == env.header.moduleData.size do
    throwError "Imported module/data inventory size mismatch"
  let mut rawNames : NameSet := {}
  let mut seenModules : Array String := #[]
  for h : idx in [0:env.header.modules.size] do
    let mod := env.header.modules[idx]
    let moduleName := mod.module.toString
    let isProject := moduleName == "Solitaire" || moduleName.startsWith "Solitaire." ||
      moduleName == "Conjectures" || moduleName.startsWith "Conjectures."
    unless !isProject || expectedModules.contains moduleName do
      throwError "Unregistered project module in audit: {moduleName}"
    if expectedModules.contains moduleName then
      unless mod.hasData && mod.importAll do
        throwError "Project module lacks complete private data: {moduleName}"
      let data := env.header.moduleData[idx]!
      unless data.constNames == data.constants.map (·.name) do
        throwError "Serialized declaration names differ from their constants: {moduleName}"
      seenModules := seenModules.push moduleName
      let mut privateCount := 0
      for name in data.constNames do
        unless (env.find? name).isSome do
          throwError "Serialized project declaration is invisible: {moduleName}: {name}"
        rawNames := rawNames.insert name
        if (privateToUserName? name).isSome then
          privateCount := privateCount + 1
      let record := Json.mkObj [
        ("tag", toJson "module"), ("module", toJson moduleName),
        ("modern", toJson data.isModule), ("import_all", toJson mod.importAll),
        ("has_data", toJson mod.hasData),
        ("names", toJson (data.constNames.map (·.toString))),
        ("private_count", toJson privateCount)]
      logInfo m!"ALL-OWNED-JSON {record.compress}"
  unless seenModules.size == expectedModules.size &&
      expectedModules.all seenModules.contains do
    throwError "Incomplete exact project module inventory"
  let mut audited : NameSet := {}
  let mut declarations := 0
  let mut theorems := 0
  let mut privateDeclarations := 0
  for (name, info) in env.constants.toList do
    let owner := match env.getModuleIdxFor? name |>.bind (env.header.modules[·]?) with
      | some mod => mod.module.toString
      | none => ""
    let userName := privateToUserName name
    let byModule := expectedModules.contains owner
    let bySerialized := rawNames.contains name
    let byLegacy := legacyPrefixes.any (fun p => userName.toString.startsWith p)
    if byModule || bySerialized || byLegacy then
      declarations := declarations + 1
      audited := audited.insert name
      let kind := match info with
        | .axiomInfo _ => "axiom"
        | .defnInfo _ => "definition"
        | .thmInfo _ => "theorem"
        | .opaqueInfo _ => "opaque"
        | .quotInfo _ => "quotient"
        | .ctorInfo _ => "constructor"
        | .recInfo _ => "recursor"
        | .inductInfo _ => "inductive"
      if info.isTheorem then
        theorems := theorems + 1
      let privateName := privateToUserName? name
      if privateName.isSome then
        privateDeclarations := privateDeclarations + 1
      if let .axiomInfo _ := info then
        unless allowed.contains name do
          throwError "Unapproved project axiom {name}"
      let axioms ← collectAxioms name
      for axiomName in axioms do
        unless allowed.contains axiomName do
          throwError "Unapproved axiom {axiomName} in {name}"
      let record := Json.mkObj [
        ("tag", toJson "declaration"), ("name", toJson name.toString),
        ("owner", toJson owner), ("kind", toJson kind),
        ("private_user_name", toJson (privateName.map (·.toString))),
        ("by_module", toJson byModule), ("by_serialized", toJson bySerialized),
        ("by_legacy_prefix", toJson byLegacy),
        ("axioms", toJson (axioms.map (·.toString)))]
      logInfo m!"ALL-OWNED-JSON {record.compress}"
  for name in rawNames.toArray do
    unless audited.contains name do
      throwError "Serialized project declaration escaped the audit: {name}"
  for name in required do
    let _ ← getConstInfo name
    unless audited.contains name do
      throwError "Required declaration is outside audited ownership: {name}"
    let record := Json.mkObj [("tag", toJson "required"), ("name", toJson name.toString)]
    logInfo m!"ALL-OWNED-JSON {record.compress}"
  let record := Json.mkObj [
    ("tag", toJson "passed"), ("modules", toJson seenModules.size),
    ("declarations", toJson declarations), ("theorems", toJson theorems),
    ("private_declarations", toJson privateDeclarations),
    ("raw_declarations", toJson rawNames.toArray.size),
    ("required", toJson required.size), ("allowed_axioms", toJson (allowed.map (·.toString)))]
  logInfo m!"ALL-OWNED-JSON {record.compress}"
