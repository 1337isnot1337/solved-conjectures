import Conjectures.LonelinessModularCoverFastCuts
import Conjectures.LonelinessSixSpeedPrime0307B002Data
import Mathlib.Tactic.FinCases

/-! Exact bounded support checks for frames 448 through 479. -/

namespace Loneliness.Modular.SixSpeed.Prime0307.B002

set_option maxRecDepth 20000
set_option maxHeartbeats 0

theorem frame00448_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 448 3
      (fragments 448) (frames 448) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00449_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 449 3
      (fragments 449) (frames 449) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00450_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 450 3
      (fragments 450) (frames 450) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00451_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 451 3
      (fragments 451) (frames 451) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00452_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 452 3
      (fragments 452) (frames 452) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00453_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 453 3
      (fragments 453) (frames 453) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00454_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 454 3
      (fragments 454) (frames 454) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00455_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 455 3
      (fragments 455) (frames 455) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00456_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 456 3
      (fragments 456) (frames 456) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00457_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 457 3
      (fragments 457) (frames 457) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00458_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 458 3
      (fragments 458) (frames 458) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00459_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 459 3
      (fragments 459) (frames 459) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00460_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 460 3
      (fragments 460) (frames 460) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00461_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 461 3
      (fragments 461) (frames 461) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00462_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 462 3
      (fragments 462) (frames 462) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00463_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 463 3
      (fragments 463) (frames 463) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00464_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 464 3
      (fragments 464) (frames 464) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00465_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 465 3
      (fragments 465) (frames 465) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00466_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 466 3
      (fragments 466) (frames 466) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00467_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 467 3
      (fragments 467) (frames 467) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00468_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 468 3
      (fragments 468) (frames 468) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00469_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 469 3
      (fragments 469) (frames 469) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00470_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 470 3
      (fragments 470) (frames 470) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00471_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 471 3
      (fragments 471) (frames 471) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00472_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 472 3
      (fragments 472) (frames 472) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00473_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 473 3
      (fragments 473) (frames 473) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00474_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 474 3
      (fragments 474) (frames 474) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00475_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 475 3
      (fragments 475) (frames 475) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00476_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 476 3
      (fragments 476) (frames 476) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00477_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 477 3
      (fragments 477) (frames 477) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00478_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 478 3
      (fragments 478) (frames 478) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00479_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 479 3
      (fragments 479) (frames 479) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem block014_checked (j : Fin 32) :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames (j.val + 448) 3
      (fragments (j.val + 448)) (frames (j.val + 448)) = true := by
  fin_cases j
  · exact frame00448_checked
  · exact frame00449_checked
  · exact frame00450_checked
  · exact frame00451_checked
  · exact frame00452_checked
  · exact frame00453_checked
  · exact frame00454_checked
  · exact frame00455_checked
  · exact frame00456_checked
  · exact frame00457_checked
  · exact frame00458_checked
  · exact frame00459_checked
  · exact frame00460_checked
  · exact frame00461_checked
  · exact frame00462_checked
  · exact frame00463_checked
  · exact frame00464_checked
  · exact frame00465_checked
  · exact frame00466_checked
  · exact frame00467_checked
  · exact frame00468_checked
  · exact frame00469_checked
  · exact frame00470_checked
  · exact frame00471_checked
  · exact frame00472_checked
  · exact frame00473_checked
  · exact frame00474_checked
  · exact frame00475_checked
  · exact frame00476_checked
  · exact frame00477_checked
  · exact frame00478_checked
  · exact frame00479_checked

end Loneliness.Modular.SixSpeed.Prime0307.B002
