import Conjectures.LonelinessModularCoverFastCuts
import Conjectures.LonelinessSixSpeedPrime0307B002Data
import Mathlib.Tactic.FinCases

/-! Exact bounded support checks for frames 800 through 831. -/

namespace Loneliness.Modular.SixSpeed.Prime0307.B002

set_option maxRecDepth 20000
set_option maxHeartbeats 0

theorem frame00800_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 800 3
      (fragments 800) (frames 800) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00801_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 801 3
      (fragments 801) (frames 801) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00802_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 802 3
      (fragments 802) (frames 802) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00803_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 803 3
      (fragments 803) (frames 803) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00804_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 804 3
      (fragments 804) (frames 804) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00805_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 805 3
      (fragments 805) (frames 805) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00806_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 806 3
      (fragments 806) (frames 806) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00807_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 807 3
      (fragments 807) (frames 807) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00808_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 808 3
      (fragments 808) (frames 808) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00809_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 809 3
      (fragments 809) (frames 809) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00810_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 810 3
      (fragments 810) (frames 810) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00811_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 811 3
      (fragments 811) (frames 811) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00812_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 812 3
      (fragments 812) (frames 812) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00813_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 813 3
      (fragments 813) (frames 813) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00814_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 814 3
      (fragments 814) (frames 814) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00815_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 815 3
      (fragments 815) (frames 815) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00816_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 816 3
      (fragments 816) (frames 816) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00817_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 817 3
      (fragments 817) (frames 817) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00818_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 818 3
      (fragments 818) (frames 818) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00819_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 819 3
      (fragments 819) (frames 819) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00820_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 820 3
      (fragments 820) (frames 820) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00821_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 821 3
      (fragments 821) (frames 821) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00822_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 822 3
      (fragments 822) (frames 822) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00823_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 823 3
      (fragments 823) (frames 823) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00824_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 824 3
      (fragments 824) (frames 824) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00825_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 825 3
      (fragments 825) (frames 825) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00826_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 826 3
      (fragments 826) (frames 826) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00827_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 827 3
      (fragments 827) (frames 827) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00828_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 828 3
      (fragments 828) (frames 828) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00829_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 829 3
      (fragments 829) (frames 829) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00830_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 830 3
      (fragments 830) (frames 830) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00831_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 831 3
      (fragments 831) (frames 831) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem block025_checked (j : Fin 32) :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames (j.val + 800) 3
      (fragments (j.val + 800)) (frames (j.val + 800)) = true := by
  fin_cases j
  · exact frame00800_checked
  · exact frame00801_checked
  · exact frame00802_checked
  · exact frame00803_checked
  · exact frame00804_checked
  · exact frame00805_checked
  · exact frame00806_checked
  · exact frame00807_checked
  · exact frame00808_checked
  · exact frame00809_checked
  · exact frame00810_checked
  · exact frame00811_checked
  · exact frame00812_checked
  · exact frame00813_checked
  · exact frame00814_checked
  · exact frame00815_checked
  · exact frame00816_checked
  · exact frame00817_checked
  · exact frame00818_checked
  · exact frame00819_checked
  · exact frame00820_checked
  · exact frame00821_checked
  · exact frame00822_checked
  · exact frame00823_checked
  · exact frame00824_checked
  · exact frame00825_checked
  · exact frame00826_checked
  · exact frame00827_checked
  · exact frame00828_checked
  · exact frame00829_checked
  · exact frame00830_checked
  · exact frame00831_checked

end Loneliness.Modular.SixSpeed.Prime0307.B002
