import Conjectures.LonelinessModularCoverFastCuts
import Conjectures.LonelinessSixSpeedPrime0307B002Data
import Mathlib.Tactic.FinCases

/-! Exact bounded support checks for frames 576 through 607. -/

namespace Loneliness.Modular.SixSpeed.Prime0307.B002

set_option maxRecDepth 20000
set_option maxHeartbeats 0

theorem frame00576_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 576 3
      (fragments 576) (frames 576) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00577_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 577 3
      (fragments 577) (frames 577) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00578_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 578 3
      (fragments 578) (frames 578) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00579_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 579 3
      (fragments 579) (frames 579) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00580_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 580 3
      (fragments 580) (frames 580) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00581_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 581 3
      (fragments 581) (frames 581) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00582_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 582 3
      (fragments 582) (frames 582) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00583_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 583 3
      (fragments 583) (frames 583) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00584_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 584 3
      (fragments 584) (frames 584) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00585_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 585 3
      (fragments 585) (frames 585) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00586_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 586 3
      (fragments 586) (frames 586) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00587_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 587 3
      (fragments 587) (frames 587) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00588_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 588 3
      (fragments 588) (frames 588) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00589_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 589 3
      (fragments 589) (frames 589) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00590_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 590 3
      (fragments 590) (frames 590) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00591_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 591 3
      (fragments 591) (frames 591) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00592_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 592 3
      (fragments 592) (frames 592) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00593_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 593 3
      (fragments 593) (frames 593) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00594_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 594 3
      (fragments 594) (frames 594) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00595_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 595 3
      (fragments 595) (frames 595) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00596_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 596 3
      (fragments 596) (frames 596) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00597_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 597 3
      (fragments 597) (frames 597) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00598_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 598 3
      (fragments 598) (frames 598) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00599_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 599 3
      (fragments 599) (frames 599) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00600_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 600 3
      (fragments 600) (frames 600) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00601_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 601 3
      (fragments 601) (frames 601) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00602_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 602 3
      (fragments 602) (frames 602) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00603_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 603 3
      (fragments 603) (frames 603) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00604_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 604 3
      (fragments 604) (frames 604) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00605_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 605 3
      (fragments 605) (frames 605) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00606_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 606 3
      (fragments 606) (frames 606) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00607_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 607 3
      (fragments 607) (frames 607) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem block018_checked (j : Fin 32) :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames (j.val + 576) 3
      (fragments (j.val + 576)) (frames (j.val + 576)) = true := by
  fin_cases j
  · exact frame00576_checked
  · exact frame00577_checked
  · exact frame00578_checked
  · exact frame00579_checked
  · exact frame00580_checked
  · exact frame00581_checked
  · exact frame00582_checked
  · exact frame00583_checked
  · exact frame00584_checked
  · exact frame00585_checked
  · exact frame00586_checked
  · exact frame00587_checked
  · exact frame00588_checked
  · exact frame00589_checked
  · exact frame00590_checked
  · exact frame00591_checked
  · exact frame00592_checked
  · exact frame00593_checked
  · exact frame00594_checked
  · exact frame00595_checked
  · exact frame00596_checked
  · exact frame00597_checked
  · exact frame00598_checked
  · exact frame00599_checked
  · exact frame00600_checked
  · exact frame00601_checked
  · exact frame00602_checked
  · exact frame00603_checked
  · exact frame00604_checked
  · exact frame00605_checked
  · exact frame00606_checked
  · exact frame00607_checked

end Loneliness.Modular.SixSpeed.Prime0307.B002
