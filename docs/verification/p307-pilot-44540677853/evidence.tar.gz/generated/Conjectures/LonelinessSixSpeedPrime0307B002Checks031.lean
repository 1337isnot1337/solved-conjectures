import Conjectures.LonelinessModularCoverFastCuts
import Conjectures.LonelinessSixSpeedPrime0307B002Data
import Mathlib.Tactic.FinCases

/-! Exact bounded support checks for frames 992 through 1023. -/

namespace Loneliness.Modular.SixSpeed.Prime0307.B002

set_option maxRecDepth 20000
set_option maxHeartbeats 0

theorem frame00992_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 992 3
      (fragments 992) (frames 992) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00993_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 993 3
      (fragments 993) (frames 993) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00994_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 994 3
      (fragments 994) (frames 994) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00995_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 995 3
      (fragments 995) (frames 995) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00996_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 996 3
      (fragments 996) (frames 996) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00997_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 997 3
      (fragments 997) (frames 997) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00998_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 998 3
      (fragments 998) (frames 998) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00999_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 999 3
      (fragments 999) (frames 999) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01000_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1000 3
      (fragments 1000) (frames 1000) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01001_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1001 3
      (fragments 1001) (frames 1001) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01002_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1002 3
      (fragments 1002) (frames 1002) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01003_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1003 3
      (fragments 1003) (frames 1003) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01004_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1004 3
      (fragments 1004) (frames 1004) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01005_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1005 3
      (fragments 1005) (frames 1005) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01006_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1006 3
      (fragments 1006) (frames 1006) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01007_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1007 3
      (fragments 1007) (frames 1007) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01008_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1008 3
      (fragments 1008) (frames 1008) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01009_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1009 3
      (fragments 1009) (frames 1009) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01010_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1010 3
      (fragments 1010) (frames 1010) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01011_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1011 3
      (fragments 1011) (frames 1011) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01012_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1012 3
      (fragments 1012) (frames 1012) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01013_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1013 3
      (fragments 1013) (frames 1013) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01014_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1014 3
      (fragments 1014) (frames 1014) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01015_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1015 3
      (fragments 1015) (frames 1015) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01016_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1016 3
      (fragments 1016) (frames 1016) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01017_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1017 3
      (fragments 1017) (frames 1017) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01018_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1018 3
      (fragments 1018) (frames 1018) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01019_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1019 3
      (fragments 1019) (frames 1019) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01020_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1020 3
      (fragments 1020) (frames 1020) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01021_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1021 3
      (fragments 1021) (frames 1021) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01022_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1022 3
      (fragments 1022) (frames 1022) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame01023_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 1023 3
      (fragments 1023) (frames 1023) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem block031_checked (j : Fin 32) :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames (j.val + 992) 3
      (fragments (j.val + 992)) (frames (j.val + 992)) = true := by
  fin_cases j
  · exact frame00992_checked
  · exact frame00993_checked
  · exact frame00994_checked
  · exact frame00995_checked
  · exact frame00996_checked
  · exact frame00997_checked
  · exact frame00998_checked
  · exact frame00999_checked
  · exact frame01000_checked
  · exact frame01001_checked
  · exact frame01002_checked
  · exact frame01003_checked
  · exact frame01004_checked
  · exact frame01005_checked
  · exact frame01006_checked
  · exact frame01007_checked
  · exact frame01008_checked
  · exact frame01009_checked
  · exact frame01010_checked
  · exact frame01011_checked
  · exact frame01012_checked
  · exact frame01013_checked
  · exact frame01014_checked
  · exact frame01015_checked
  · exact frame01016_checked
  · exact frame01017_checked
  · exact frame01018_checked
  · exact frame01019_checked
  · exact frame01020_checked
  · exact frame01021_checked
  · exact frame01022_checked
  · exact frame01023_checked

end Loneliness.Modular.SixSpeed.Prime0307.B002
