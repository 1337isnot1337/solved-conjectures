import Conjectures.LonelinessModularCoverFastCuts
import Conjectures.LonelinessSixSpeedPrime0307B002Data
import Mathlib.Tactic.FinCases

/-! Exact bounded support checks for frames 192 through 223. -/

namespace Loneliness.Modular.SixSpeed.Prime0307.B002

set_option maxRecDepth 20000
set_option maxHeartbeats 0

theorem frame00192_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 192 3
      (fragments 192) (frames 192) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00193_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 193 3
      (fragments 193) (frames 193) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00194_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 194 3
      (fragments 194) (frames 194) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00195_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 195 3
      (fragments 195) (frames 195) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00196_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 196 3
      (fragments 196) (frames 196) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00197_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 197 3
      (fragments 197) (frames 197) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00198_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 198 3
      (fragments 198) (frames 198) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00199_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 199 3
      (fragments 199) (frames 199) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00200_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 200 3
      (fragments 200) (frames 200) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00201_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 201 3
      (fragments 201) (frames 201) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00202_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 202 3
      (fragments 202) (frames 202) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00203_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 203 3
      (fragments 203) (frames 203) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00204_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 204 3
      (fragments 204) (frames 204) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00205_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 205 3
      (fragments 205) (frames 205) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00206_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 206 3
      (fragments 206) (frames 206) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00207_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 207 3
      (fragments 207) (frames 207) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00208_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 208 3
      (fragments 208) (frames 208) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00209_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 209 3
      (fragments 209) (frames 209) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00210_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 210 3
      (fragments 210) (frames 210) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00211_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 211 3
      (fragments 211) (frames 211) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00212_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 212 3
      (fragments 212) (frames 212) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00213_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 213 3
      (fragments 213) (frames 213) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00214_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 214 3
      (fragments 214) (frames 214) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00215_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 215 3
      (fragments 215) (frames 215) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00216_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 216 3
      (fragments 216) (frames 216) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00217_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 217 3
      (fragments 217) (frames 217) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00218_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 218 3
      (fragments 218) (frames 218) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00219_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 219 3
      (fragments 219) (frames 219) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00220_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 220 3
      (fragments 220) (frames 220) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00221_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 221 3
      (fragments 221) (frames 221) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00222_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 222 3
      (fragments 222) (frames 222) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem frame00223_checked :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames 223 3
      (fragments 223) (frames 223) = true := by
  apply SupportSearch.Bits.FastCuts.boundedCheck_sound
  decide +kernel

theorem block006_checked (j : Fin 32) :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames (j.val + 192) 3
      (fragments (j.val + 192)) (frames (j.val + 192)) = true := by
  fin_cases j
  · exact frame00192_checked
  · exact frame00193_checked
  · exact frame00194_checked
  · exact frame00195_checked
  · exact frame00196_checked
  · exact frame00197_checked
  · exact frame00198_checked
  · exact frame00199_checked
  · exact frame00200_checked
  · exact frame00201_checked
  · exact frame00202_checked
  · exact frame00203_checked
  · exact frame00204_checked
  · exact frame00205_checked
  · exact frame00206_checked
  · exact frame00207_checked
  · exact frame00208_checked
  · exact frame00209_checked
  · exact frame00210_checked
  · exact frame00211_checked
  · exact frame00212_checked
  · exact frame00213_checked
  · exact frame00214_checked
  · exact frame00215_checked
  · exact frame00216_checked
  · exact frame00217_checked
  · exact frame00218_checked
  · exact frame00219_checked
  · exact frame00220_checked
  · exact frame00221_checked
  · exact frame00222_checked
  · exact frame00223_checked

end Loneliness.Modular.SixSpeed.Prime0307.B002
