import Conjectures.Loneliness
import Conjectures.LonelinessContinuity
import Conjectures.LonelinessCriticalBase
import Conjectures.LonelinessFiveFamily
import Conjectures.LonelinessFourSpeedCertificate
import Conjectures.LonelinessFourSpeedEnumeration
import Conjectures.LonelinessModularCoverBits
import Conjectures.LonelinessModularCoverChunks
import Conjectures.LonelinessModularCoverCuts
import Conjectures.LonelinessModularCoverFastCounts
import Conjectures.LonelinessModularCoverFastCuts
import Conjectures.LonelinessModularCoverSearch
import Conjectures.LonelinessModularCoverTape
import Conjectures.LonelinessModularInitialBits
import Conjectures.LonelinessModularInitialMemo
import Conjectures.LonelinessModularInitialSupport
import Conjectures.LonelinessModularMemo
import Conjectures.LonelinessModularNormalize
import Conjectures.LonelinessModularRationalWitness
import Conjectures.LonelinessModularStrictWitness
import Conjectures.LonelinessModularSupportLists
import Conjectures.LonelinessModularSupportListsN09D10P0017
import Conjectures.LonelinessModularSupportListsN09D10P0017Arithmetic
import Conjectures.LonelinessModularSupportListsN09D10P0017B0002
import Conjectures.LonelinessModularSupportListsN09D10P0017B0002Arithmetic
import Conjectures.LonelinessModularSupportListsN09D10P0017B0002Checks0000
import Conjectures.LonelinessModularSupportListsN09D10P0017B0002Checks0001
import Conjectures.LonelinessModularSupportListsN09D10P0017B0002Checks0002
import Conjectures.LonelinessModularSupportListsN09D10P0017B0002Checks0003
import Conjectures.LonelinessModularSupportListsN09D10P0017B0002Data
import Conjectures.LonelinessModularSupportListsN09D10P0017B0003
import Conjectures.LonelinessModularSupportListsN09D10P0017B0003Arithmetic
import Conjectures.LonelinessModularSupportListsN09D10P0017B0003Checks0000
import Conjectures.LonelinessModularSupportListsN09D10P0017B0003Data
import Conjectures.LonelinessModularSupportListsN09D10P0017B0004
import Conjectures.LonelinessModularSupportListsN09D10P0017B0004Arithmetic
import Conjectures.LonelinessModularSupportListsN09D10P0017B0004Checks0000
import Conjectures.LonelinessModularSupportListsN09D10P0017B0004Data
import Conjectures.LonelinessModularSupportListsN09D10P0017B0005
import Conjectures.LonelinessModularSupportListsN09D10P0017B0005Arithmetic
import Conjectures.LonelinessModularSupportListsN09D10P0017B0005Checks0000
import Conjectures.LonelinessModularSupportListsN09D10P0017B0005Data
import Conjectures.LonelinessModularSupportListsN09D10P0017B0006
import Conjectures.LonelinessModularSupportListsN09D10P0017B0006Arithmetic
import Conjectures.LonelinessModularSupportListsN09D10P0017B0006Checks0000
import Conjectures.LonelinessModularSupportListsN09D10P0017B0006Data
import Conjectures.LonelinessModularSupportListsN09D10P0017B0007
import Conjectures.LonelinessModularSupportListsN09D10P0017B0007Arithmetic
import Conjectures.LonelinessModularSupportListsN09D10P0017B0007Checks0000
import Conjectures.LonelinessModularSupportListsN09D10P0017B0007Data
import Conjectures.LonelinessModularSupportListsN09D10P0017B0008
import Conjectures.LonelinessModularSupportListsN09D10P0017B0008Arithmetic
import Conjectures.LonelinessModularSupportListsN09D10P0017B0008Checks0000
import Conjectures.LonelinessModularSupportListsN09D10P0017B0008Data
import Conjectures.LonelinessModularSupportListsN09D10P0017Rows
import Conjectures.LonelinessModularSupportListsN09D10P0017RowsChecks0000
import Conjectures.LonelinessModularSupportListsN09D10P0017RowsData
import Conjectures.LonelinessModularWitness
import Conjectures.LonelinessRational
import Lean.Util.CollectAxioms
import Lean.PrivateName
import Lean.Elab.Command
import Lean.Data.Json

set_option maxRecDepth 100000
set_option maxHeartbeats 0

open Lean Elab Command in
run_cmd do
  let expectedModules : Array String := #["Conjectures.Loneliness", "Conjectures.LonelinessContinuity", "Conjectures.LonelinessCriticalBase", "Conjectures.LonelinessFiveFamily", "Conjectures.LonelinessFourSpeedCertificate", "Conjectures.LonelinessFourSpeedEnumeration", "Conjectures.LonelinessModularCoverBits", "Conjectures.LonelinessModularCoverChunks", "Conjectures.LonelinessModularCoverCuts", "Conjectures.LonelinessModularCoverFastCounts", "Conjectures.LonelinessModularCoverFastCuts", "Conjectures.LonelinessModularCoverSearch", "Conjectures.LonelinessModularCoverTape", "Conjectures.LonelinessModularInitialBits", "Conjectures.LonelinessModularInitialMemo", "Conjectures.LonelinessModularInitialSupport", "Conjectures.LonelinessModularMemo", "Conjectures.LonelinessModularNormalize", "Conjectures.LonelinessModularRationalWitness", "Conjectures.LonelinessModularStrictWitness", "Conjectures.LonelinessModularSupportLists", "Conjectures.LonelinessModularSupportListsN09D10P0017", "Conjectures.LonelinessModularSupportListsN09D10P0017Arithmetic", "Conjectures.LonelinessModularSupportListsN09D10P0017B0002", "Conjectures.LonelinessModularSupportListsN09D10P0017B0002Arithmetic", "Conjectures.LonelinessModularSupportListsN09D10P0017B0002Checks0000", "Conjectures.LonelinessModularSupportListsN09D10P0017B0002Checks0001", "Conjectures.LonelinessModularSupportListsN09D10P0017B0002Checks0002", "Conjectures.LonelinessModularSupportListsN09D10P0017B0002Checks0003", "Conjectures.LonelinessModularSupportListsN09D10P0017B0002Data", "Conjectures.LonelinessModularSupportListsN09D10P0017B0003", "Conjectures.LonelinessModularSupportListsN09D10P0017B0003Arithmetic", "Conjectures.LonelinessModularSupportListsN09D10P0017B0003Checks0000", "Conjectures.LonelinessModularSupportListsN09D10P0017B0003Data", "Conjectures.LonelinessModularSupportListsN09D10P0017B0004", "Conjectures.LonelinessModularSupportListsN09D10P0017B0004Arithmetic", "Conjectures.LonelinessModularSupportListsN09D10P0017B0004Checks0000", "Conjectures.LonelinessModularSupportListsN09D10P0017B0004Data", "Conjectures.LonelinessModularSupportListsN09D10P0017B0005", "Conjectures.LonelinessModularSupportListsN09D10P0017B0005Arithmetic", "Conjectures.LonelinessModularSupportListsN09D10P0017B0005Checks0000", "Conjectures.LonelinessModularSupportListsN09D10P0017B0005Data", "Conjectures.LonelinessModularSupportListsN09D10P0017B0006", "Conjectures.LonelinessModularSupportListsN09D10P0017B0006Arithmetic", "Conjectures.LonelinessModularSupportListsN09D10P0017B0006Checks0000", "Conjectures.LonelinessModularSupportListsN09D10P0017B0006Data", "Conjectures.LonelinessModularSupportListsN09D10P0017B0007", "Conjectures.LonelinessModularSupportListsN09D10P0017B0007Arithmetic", "Conjectures.LonelinessModularSupportListsN09D10P0017B0007Checks0000", "Conjectures.LonelinessModularSupportListsN09D10P0017B0007Data", "Conjectures.LonelinessModularSupportListsN09D10P0017B0008", "Conjectures.LonelinessModularSupportListsN09D10P0017B0008Arithmetic", "Conjectures.LonelinessModularSupportListsN09D10P0017B0008Checks0000", "Conjectures.LonelinessModularSupportListsN09D10P0017B0008Data", "Conjectures.LonelinessModularSupportListsN09D10P0017Rows", "Conjectures.LonelinessModularSupportListsN09D10P0017RowsChecks0000", "Conjectures.LonelinessModularSupportListsN09D10P0017RowsData", "Conjectures.LonelinessModularWitness", "Conjectures.LonelinessRational"]
  let required : Array Name := #[`Loneliness.Modular.SupportLists.N09D10P0017.B0002.root_checked, `Loneliness.Modular.SupportLists.N09D10P0017.B0003.root_checked, `Loneliness.Modular.SupportLists.N09D10P0017.B0004.root_checked, `Loneliness.Modular.SupportLists.N09D10P0017.B0005.root_checked, `Loneliness.Modular.SupportLists.N09D10P0017.B0006.root_checked, `Loneliness.Modular.SupportLists.N09D10P0017.B0007.root_checked, `Loneliness.Modular.SupportLists.N09D10P0017.B0008.root_checked, `Loneliness.Modular.SupportLists.N09D10P0017.cover_checked, `Loneliness.Modular.SupportLists.N09D10P0017.exact_survivors, `Loneliness.Modular.SupportLists.N09D10P0017.initial_checked, `Loneliness.Modular.SupportLists.N09D10P0017.inverse_valid, `Loneliness.Modular.SupportLists.N09D10P0017.normalized_cover, `Loneliness.Modular.SupportLists.N09D10P0017.row000000_valid, `Loneliness.Modular.SupportLists.N09D10P0017.rows_valid, `Loneliness.Modular.SupportLists.checked_list_cover, `Loneliness.Modular.SupportLists.checked_survivor_iff, `Loneliness.Modular.SupportLists.checked_survivor_mem, `Loneliness.Modular.SupportLists.covers_times_iff_no_rational_witness, `Loneliness.Modular.SupportLists.survivor_no_rational_witness, `Loneliness.Modular.SupportLists.terminal_sound, `Loneliness.Modular.SupportSearch.Bits.Fast.count_eq, `Loneliness.Modular.SupportSearch.Bits.FastCuts.boundedCheck_eq, `Loneliness.Modular.SupportSearch.Bits.FastCuts.boundedCheck_sound]
  let legacyPrefixes : Array String := #["Loneliness."]
  let allowed : Array Name := #[`propext, `Classical.choice, `Quot.sound]
  let env ← getEnv
  if env.header.isModule then
    throwError "All-owned audit must use legacy private-import mode"
  unless env.header.modules.size == env.header.moduleData.size do
    throwError "Imported module/data inventory size mismatch"
  let mut rawNames : NameSet := {}
  let mut seenModules : Array String := #[]
  for h : idx in [0:env.header.modules.size] do
    let mod := env.header.modules[idx]
    let moduleName := mod.module.toString
    let isProject := moduleName == "Solitaire" || moduleName.startsWith "Solitaire." ||
      moduleName == "Conjectures" || moduleName.startsWith "Conjectures."
    unless !isProject || expectedModules.contains moduleName do
      throwError "Unregistered project module in audit: {moduleName}"
    if expectedModules.contains moduleName then
      unless mod.hasData && mod.importAll do
        throwError "Project module lacks complete private data: {moduleName}"
      let data := env.header.moduleData[idx]!
      unless data.constNames == data.constants.map (·.name) do
        throwError "Serialized declaration names differ from their constants: {moduleName}"
      seenModules := seenModules.push moduleName
      let mut privateCount := 0
      for name in data.constNames do
        unless (env.find? name).isSome do
          throwError "Serialized project declaration is invisible: {moduleName}: {name}"
        rawNames := rawNames.insert name
        if (privateToUserName? name).isSome then
          privateCount := privateCount + 1
      let record := Json.mkObj [
        ("tag", toJson "module"), ("module", toJson moduleName),
        ("modern", toJson data.isModule), ("import_all", toJson mod.importAll),
        ("has_data", toJson mod.hasData),
        ("names", toJson (data.constNames.map (·.toString))),
        ("private_count", toJson privateCount)]
      logInfo m!"ALL-OWNED-JSON {record.compress}"
  unless seenModules.size == expectedModules.size &&
      expectedModules.all seenModules.contains do
    throwError "Incomplete exact project module inventory"
  let mut audited : NameSet := {}
  let mut declarations := 0
  let mut theorems := 0
  let mut privateDeclarations := 0
  for (name, info) in env.constants.toList do
    let owner := match env.getModuleIdxFor? name |>.bind (env.header.modules[·]?) with
      | some mod => mod.module.toString
      | none => ""
    let userName := privateToUserName name
    let byModule := expectedModules.contains owner
    let bySerialized := rawNames.contains name
    let byLegacy := legacyPrefixes.any (fun p => userName.toString.startsWith p)
    if byModule || bySerialized || byLegacy then
      declarations := declarations + 1
      audited := audited.insert name
      let kind := match info with
        | .axiomInfo _ => "axiom"
        | .defnInfo _ => "definition"
        | .thmInfo _ => "theorem"
        | .opaqueInfo _ => "opaque"
        | .quotInfo _ => "quotient"
        | .ctorInfo _ => "constructor"
        | .recInfo _ => "recursor"
        | .inductInfo _ => "inductive"
      if info.isTheorem then
        theorems := theorems + 1
      let privateName := privateToUserName? name
      if privateName.isSome then
        privateDeclarations := privateDeclarations + 1
      if let .axiomInfo _ := info then
        unless allowed.contains name do
          throwError "Unapproved project axiom {name}"
      let axioms ← collectAxioms name
      for axiomName in axioms do
        unless allowed.contains axiomName do
          throwError "Unapproved axiom {axiomName} in {name}"
      let record := Json.mkObj [
        ("tag", toJson "declaration"), ("name", toJson name.toString),
        ("owner", toJson owner), ("kind", toJson kind),
        ("private_user_name", toJson (privateName.map (·.toString))),
        ("by_module", toJson byModule), ("by_serialized", toJson bySerialized),
        ("by_legacy_prefix", toJson byLegacy),
        ("axioms", toJson (axioms.map (·.toString)))]
      logInfo m!"ALL-OWNED-JSON {record.compress}"
  for name in rawNames.toArray do
    unless audited.contains name do
      throwError "Serialized project declaration escaped the audit: {name}"
  for name in required do
    let _ ← getConstInfo name
    unless audited.contains name do
      throwError "Required declaration is outside audited ownership: {name}"
    let record := Json.mkObj [("tag", toJson "required"), ("name", toJson name.toString)]
    logInfo m!"ALL-OWNED-JSON {record.compress}"
  let record := Json.mkObj [
    ("tag", toJson "passed"), ("modules", toJson seenModules.size),
    ("declarations", toJson declarations), ("theorems", toJson theorems),
    ("private_declarations", toJson privateDeclarations),
    ("raw_declarations", toJson rawNames.toArray.size),
    ("required", toJson required.size), ("allowed_axioms", toJson (allowed.map (·.toString)))]
  logInfo m!"ALL-OWNED-JSON {record.compress}"
