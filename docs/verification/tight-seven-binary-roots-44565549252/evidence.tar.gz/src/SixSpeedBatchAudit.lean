import Conjectures.Loneliness
import Conjectures.LonelinessCoalescence
import Conjectures.LonelinessCoalescenceValue
import Conjectures.LonelinessContinuity
import Conjectures.LonelinessCoordinateClasses
import Conjectures.LonelinessCoordinateSubspace
import Conjectures.LonelinessCriticalBase
import Conjectures.LonelinessCriticalFamilies
import Conjectures.LonelinessCriticalSecond
import Conjectures.LonelinessFiveFamily
import Conjectures.LonelinessIntegerDirection
import Conjectures.LonelinessModularClosedFoldedDirections
import Conjectures.LonelinessModularClosedFoldedSearch
import Conjectures.LonelinessModularClosedShortVector
import Conjectures.LonelinessModularDirections
import Conjectures.LonelinessModularFoldedSearch
import Conjectures.LonelinessModularForcedDivisor
import Conjectures.LonelinessModularLift
import Conjectures.LonelinessModularNormalize
import Conjectures.LonelinessModularParity
import Conjectures.LonelinessModularPlaneGap
import Conjectures.LonelinessModularPrimes
import Conjectures.LonelinessModularRationalWitness
import Conjectures.LonelinessModularSearch
import Conjectures.LonelinessModularSearchDirections
import Conjectures.LonelinessModularShortVector
import Conjectures.LonelinessModularStrictWitness
import Conjectures.LonelinessModularTightPrimeDefs
import Conjectures.LonelinessModularWitness
import Conjectures.LonelinessNormalization
import Conjectures.LonelinessRational
import Conjectures.LonelinessRationalSubspace
import Conjectures.LonelinessSubspaceDensity
import Conjectures.LonelinessTightSevenBinaryRoots
import Lean.Util.CollectAxioms
import Lean.PrivateName
import Lean.Elab.Command
import Lean.Data.Json

set_option maxRecDepth 100000
set_option maxHeartbeats 0

open Lean Elab Command in
run_cmd do
  let expectedModules : Array String := #["Conjectures.Loneliness", "Conjectures.LonelinessCoalescence", "Conjectures.LonelinessCoalescenceValue", "Conjectures.LonelinessContinuity", "Conjectures.LonelinessCoordinateClasses", "Conjectures.LonelinessCoordinateSubspace", "Conjectures.LonelinessCriticalBase", "Conjectures.LonelinessCriticalFamilies", "Conjectures.LonelinessCriticalSecond", "Conjectures.LonelinessFiveFamily", "Conjectures.LonelinessIntegerDirection", "Conjectures.LonelinessModularClosedFoldedDirections", "Conjectures.LonelinessModularClosedFoldedSearch", "Conjectures.LonelinessModularClosedShortVector", "Conjectures.LonelinessModularDirections", "Conjectures.LonelinessModularFoldedSearch", "Conjectures.LonelinessModularForcedDivisor", "Conjectures.LonelinessModularLift", "Conjectures.LonelinessModularNormalize", "Conjectures.LonelinessModularParity", "Conjectures.LonelinessModularPlaneGap", "Conjectures.LonelinessModularPrimes", "Conjectures.LonelinessModularRationalWitness", "Conjectures.LonelinessModularSearch", "Conjectures.LonelinessModularSearchDirections", "Conjectures.LonelinessModularShortVector", "Conjectures.LonelinessModularStrictWitness", "Conjectures.LonelinessModularTightPrimeDefs", "Conjectures.LonelinessModularWitness", "Conjectures.LonelinessNormalization", "Conjectures.LonelinessRational", "Conjectures.LonelinessRationalSubspace", "Conjectures.LonelinessSubspaceDensity", "Conjectures.LonelinessTightSevenBinaryRoots"]
  let required : Array Name := #[`Loneliness.Modular.TightSevenBinaryRoots.all_checked, `Loneliness.Modular.TightSevenBinaryRoots.checked_0251_0, `Loneliness.Modular.TightSevenBinaryRoots.checked_0251_1, `Loneliness.Modular.TightSevenBinaryRoots.checked_0251_2, `Loneliness.Modular.TightSevenBinaryRoots.checked_0257_0, `Loneliness.Modular.TightSevenBinaryRoots.checked_0257_1, `Loneliness.Modular.TightSevenBinaryRoots.checked_0257_2, `Loneliness.Modular.TightSevenBinaryRoots.checked_0263_0, `Loneliness.Modular.TightSevenBinaryRoots.checked_0263_1, `Loneliness.Modular.TightSevenBinaryRoots.checked_0263_2, `Loneliness.Modular.TightSevenBinaryRoots.checked_0269_0, `Loneliness.Modular.TightSevenBinaryRoots.checked_0269_1, `Loneliness.Modular.TightSevenBinaryRoots.checked_0269_2, `Loneliness.Modular.TightSevenBinaryRoots.checked_0271_0, `Loneliness.Modular.TightSevenBinaryRoots.checked_0271_1, `Loneliness.Modular.TightSevenBinaryRoots.checked_0271_2, `Loneliness.Modular.TightSevenBinaryRoots.checked_0277_0, `Loneliness.Modular.TightSevenBinaryRoots.checked_0277_1, `Loneliness.Modular.TightSevenBinaryRoots.checked_0277_2, `Loneliness.Modular.TightSevenBinaryRoots.checked_0281_0, `Loneliness.Modular.TightSevenBinaryRoots.checked_0281_1, `Loneliness.Modular.TightSevenBinaryRoots.checked_0281_2, `Loneliness.Modular.TightSevenBinaryRoots.checked_0283_0, `Loneliness.Modular.TightSevenBinaryRoots.checked_0283_1, `Loneliness.Modular.TightSevenBinaryRoots.checked_0283_2, `Loneliness.Modular.TightSevenBinaryRoots.checked_0293_0, `Loneliness.Modular.TightSevenBinaryRoots.checked_0293_1, `Loneliness.Modular.TightSevenBinaryRoots.checked_0293_2, `Loneliness.Modular.TightSevenBinaryRoots.checked_0307_0, `Loneliness.Modular.TightSevenBinaryRoots.checked_0307_1, `Loneliness.Modular.TightSevenBinaryRoots.checked_0307_2, `Loneliness.Modular.TightSevenBinaryRoots.checked_0311_0, `Loneliness.Modular.TightSevenBinaryRoots.checked_0311_1, `Loneliness.Modular.TightSevenBinaryRoots.checked_0311_2, `Loneliness.Modular.TightSevenBinaryRoots.checked_0313_0, `Loneliness.Modular.TightSevenBinaryRoots.checked_0313_1, `Loneliness.Modular.TightSevenBinaryRoots.checked_0313_2, `Loneliness.Modular.TightSevenBinaryRoots.checked_0317_0, `Loneliness.Modular.TightSevenBinaryRoots.checked_0317_1, `Loneliness.Modular.TightSevenBinaryRoots.checked_0317_2, `Loneliness.Modular.TightSevenBinaryRoots.checked_0331_0, `Loneliness.Modular.TightSevenBinaryRoots.checked_0331_1, `Loneliness.Modular.TightSevenBinaryRoots.checked_0331_2, `Loneliness.Modular.TightSevenBinaryRoots.checked_0337_0, `Loneliness.Modular.TightSevenBinaryRoots.checked_0337_1, `Loneliness.Modular.TightSevenBinaryRoots.checked_0337_2, `Loneliness.Modular.TightSevenBinaryRoots.checked_0347_0, `Loneliness.Modular.TightSevenBinaryRoots.checked_0347_1, `Loneliness.Modular.TightSevenBinaryRoots.checked_0347_2, `Loneliness.Modular.TightSevenBinaryRoots.checked_0349_0, `Loneliness.Modular.TightSevenBinaryRoots.checked_0349_1, `Loneliness.Modular.TightSevenBinaryRoots.checked_0349_2, `Loneliness.Modular.TightSevenBinaryRoots.classify_original_prime_root, `Loneliness.Modular.TightSevenBinaryRoots.classify_original_shape, `Loneliness.Modular.TightSevenBinaryRoots.classify_root, `Loneliness.Modular.TightSevenBinaryRoots.prime_set_exact, `Loneliness.Modular.TightSevenBinaryRoots.primes_gt_one, `Loneliness.Modular.TightSevenBinaryRoots.root_lists_exact]
  let legacyPrefixes : Array String := #["Loneliness."]
  let allowed : Array Name := #[`propext, `Classical.choice, `Quot.sound]
  let env ← getEnv
  if env.header.isModule then
    throwError "All-owned audit must use legacy private-import mode"
  unless env.header.modules.size == env.header.moduleData.size do
    throwError "Imported module/data inventory size mismatch"
  let mut rawNames : NameSet := {}
  let mut seenModules : Array String := #[]
  for h : idx in [0:env.header.modules.size] do
    let mod := env.header.modules[idx]
    let moduleName := mod.module.toString
    let isProject := moduleName == "Solitaire" || moduleName.startsWith "Solitaire." ||
      moduleName == "Conjectures" || moduleName.startsWith "Conjectures."
    unless !isProject || expectedModules.contains moduleName do
      throwError "Unregistered project module in audit: {moduleName}"
    if expectedModules.contains moduleName then
      unless mod.hasData && mod.importAll do
        throwError "Project module lacks complete private data: {moduleName}"
      let data := env.header.moduleData[idx]!
      unless data.constNames == data.constants.map (·.name) do
        throwError "Serialized declaration names differ from their constants: {moduleName}"
      seenModules := seenModules.push moduleName
      let mut privateCount := 0
      for name in data.constNames do
        unless (env.find? name).isSome do
          throwError "Serialized project declaration is invisible: {moduleName}: {name}"
        rawNames := rawNames.insert name
        if (privateToUserName? name).isSome then
          privateCount := privateCount + 1
      let record := Json.mkObj [
        ("tag", toJson "module"), ("module", toJson moduleName),
        ("modern", toJson data.isModule), ("import_all", toJson mod.importAll),
        ("has_data", toJson mod.hasData),
        ("names", toJson (data.constNames.map (·.toString))),
        ("private_count", toJson privateCount)]
      logInfo m!"ALL-OWNED-JSON {record.compress}"
  unless seenModules.size == expectedModules.size &&
      expectedModules.all seenModules.contains do
    throwError "Incomplete exact project module inventory"
  let mut audited : NameSet := {}
  let mut declarations := 0
  let mut theorems := 0
  let mut privateDeclarations := 0
  for (name, info) in env.constants.toList do
    let owner := match env.getModuleIdxFor? name |>.bind (env.header.modules[·]?) with
      | some mod => mod.module.toString
      | none => ""
    let userName := privateToUserName name
    let byModule := expectedModules.contains owner
    let bySerialized := rawNames.contains name
    let byLegacy := legacyPrefixes.any (fun p => userName.toString.startsWith p)
    if byModule || bySerialized || byLegacy then
      declarations := declarations + 1
      audited := audited.insert name
      let kind := match info with
        | .axiomInfo _ => "axiom"
        | .defnInfo _ => "definition"
        | .thmInfo _ => "theorem"
        | .opaqueInfo _ => "opaque"
        | .quotInfo _ => "quotient"
        | .ctorInfo _ => "constructor"
        | .recInfo _ => "recursor"
        | .inductInfo _ => "inductive"
      if info.isTheorem then
        theorems := theorems + 1
      let privateName := privateToUserName? name
      if privateName.isSome then
        privateDeclarations := privateDeclarations + 1
      if let .axiomInfo _ := info then
        unless allowed.contains name do
          throwError "Unapproved project axiom {name}"
      let axioms ← collectAxioms name
      for axiomName in axioms do
        unless allowed.contains axiomName do
          throwError "Unapproved axiom {axiomName} in {name}"
      let record := Json.mkObj [
        ("tag", toJson "declaration"), ("name", toJson name.toString),
        ("owner", toJson owner), ("kind", toJson kind),
        ("private_user_name", toJson (privateName.map (·.toString))),
        ("by_module", toJson byModule), ("by_serialized", toJson bySerialized),
        ("by_legacy_prefix", toJson byLegacy),
        ("axioms", toJson (axioms.map (·.toString)))]
      logInfo m!"ALL-OWNED-JSON {record.compress}"
  for name in rawNames.toArray do
    unless audited.contains name do
      throwError "Serialized project declaration escaped the audit: {name}"
  for name in required do
    let _ ← getConstInfo name
    unless audited.contains name do
      throwError "Required declaration is outside audited ownership: {name}"
    let record := Json.mkObj [("tag", toJson "required"), ("name", toJson name.toString)]
    logInfo m!"ALL-OWNED-JSON {record.compress}"
  let record := Json.mkObj [
    ("tag", toJson "passed"), ("modules", toJson seenModules.size),
    ("declarations", toJson declarations), ("theorems", toJson theorems),
    ("private_declarations", toJson privateDeclarations),
    ("raw_declarations", toJson rawNames.toArray.size),
    ("required", toJson required.size), ("allowed_axioms", toJson (allowed.map (·.toString)))]
  logInfo m!"ALL-OWNED-JSON {record.compress}"
