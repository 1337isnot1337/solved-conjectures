import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0000
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0001
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0002
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0003
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0004
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0005
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0006
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0007
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0008
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0009
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0010
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0011
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0012
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0013
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0014
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0015
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0016
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0017
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0018
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0019
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0020
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0021
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0022
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0023
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0024
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0025
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0026
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0027
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0028
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0029
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0030
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0031
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0032
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0033
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0034
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0035
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0036
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0037
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0038
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0039
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0040
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0041
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0042
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0043
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0044
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0045
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0046
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0047
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0048
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0049
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0050
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0051
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0052
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0053
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0054
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0055
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0056
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0057
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0058
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0059
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0060
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0061
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0062
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0063
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0064
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0065
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0066
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0067
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0068
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0069
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0070
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0071
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0072
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0073
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0074
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0075
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0076
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0077
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0078
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0079
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0080
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0081
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0082
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0083
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0084
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0085
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0086
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0087
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0088
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0089
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0090
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0091
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0092
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0093
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0094
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0095
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0096
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0097
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0098
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0099
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0100
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0101
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0102
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0103
import Conjectures.LonelinessModularSupportListsN07D08P0251Cut031B0004Checks0104

/-! Assemble every exact cut for minimum pair4; all original instructions remain checked.
Generated by scripts/generate_modular_support_cut_fragments.py. -/

namespace Loneliness.Modular.SupportLists.N07D08P0251.Cut031.B0004

theorem table_checks (index : ℕ) (hi : index < 419) :
    SupportSearch.Bits.Cuts.boundedCheck coverMask compatibleMask terminal lookup frames index 31
      (fragments index) (frames index) = true := by
  by_cases h0 : index < 4
  · exact block0000_checked ⟨index, h0⟩
  by_cases h1 : index < 8
  · have hshift : index - 4 + 4 = index := by omega
    simpa only [hshift] using
      (block0001_checked ⟨index - 4, by omega⟩)
  by_cases h2 : index < 12
  · have hshift : index - 8 + 8 = index := by omega
    simpa only [hshift] using
      (block0002_checked ⟨index - 8, by omega⟩)
  by_cases h3 : index < 16
  · have hshift : index - 12 + 12 = index := by omega
    simpa only [hshift] using
      (block0003_checked ⟨index - 12, by omega⟩)
  by_cases h4 : index < 20
  · have hshift : index - 16 + 16 = index := by omega
    simpa only [hshift] using
      (block0004_checked ⟨index - 16, by omega⟩)
  by_cases h5 : index < 24
  · have hshift : index - 20 + 20 = index := by omega
    simpa only [hshift] using
      (block0005_checked ⟨index - 20, by omega⟩)
  by_cases h6 : index < 28
  · have hshift : index - 24 + 24 = index := by omega
    simpa only [hshift] using
      (block0006_checked ⟨index - 24, by omega⟩)
  by_cases h7 : index < 32
  · have hshift : index - 28 + 28 = index := by omega
    simpa only [hshift] using
      (block0007_checked ⟨index - 28, by omega⟩)
  by_cases h8 : index < 36
  · have hshift : index - 32 + 32 = index := by omega
    simpa only [hshift] using
      (block0008_checked ⟨index - 32, by omega⟩)
  by_cases h9 : index < 40
  · have hshift : index - 36 + 36 = index := by omega
    simpa only [hshift] using
      (block0009_checked ⟨index - 36, by omega⟩)
  by_cases h10 : index < 44
  · have hshift : index - 40 + 40 = index := by omega
    simpa only [hshift] using
      (block0010_checked ⟨index - 40, by omega⟩)
  by_cases h11 : index < 48
  · have hshift : index - 44 + 44 = index := by omega
    simpa only [hshift] using
      (block0011_checked ⟨index - 44, by omega⟩)
  by_cases h12 : index < 52
  · have hshift : index - 48 + 48 = index := by omega
    simpa only [hshift] using
      (block0012_checked ⟨index - 48, by omega⟩)
  by_cases h13 : index < 56
  · have hshift : index - 52 + 52 = index := by omega
    simpa only [hshift] using
      (block0013_checked ⟨index - 52, by omega⟩)
  by_cases h14 : index < 60
  · have hshift : index - 56 + 56 = index := by omega
    simpa only [hshift] using
      (block0014_checked ⟨index - 56, by omega⟩)
  by_cases h15 : index < 64
  · have hshift : index - 60 + 60 = index := by omega
    simpa only [hshift] using
      (block0015_checked ⟨index - 60, by omega⟩)
  by_cases h16 : index < 68
  · have hshift : index - 64 + 64 = index := by omega
    simpa only [hshift] using
      (block0016_checked ⟨index - 64, by omega⟩)
  by_cases h17 : index < 72
  · have hshift : index - 68 + 68 = index := by omega
    simpa only [hshift] using
      (block0017_checked ⟨index - 68, by omega⟩)
  by_cases h18 : index < 76
  · have hshift : index - 72 + 72 = index := by omega
    simpa only [hshift] using
      (block0018_checked ⟨index - 72, by omega⟩)
  by_cases h19 : index < 80
  · have hshift : index - 76 + 76 = index := by omega
    simpa only [hshift] using
      (block0019_checked ⟨index - 76, by omega⟩)
  by_cases h20 : index < 84
  · have hshift : index - 80 + 80 = index := by omega
    simpa only [hshift] using
      (block0020_checked ⟨index - 80, by omega⟩)
  by_cases h21 : index < 88
  · have hshift : index - 84 + 84 = index := by omega
    simpa only [hshift] using
      (block0021_checked ⟨index - 84, by omega⟩)
  by_cases h22 : index < 92
  · have hshift : index - 88 + 88 = index := by omega
    simpa only [hshift] using
      (block0022_checked ⟨index - 88, by omega⟩)
  by_cases h23 : index < 96
  · have hshift : index - 92 + 92 = index := by omega
    simpa only [hshift] using
      (block0023_checked ⟨index - 92, by omega⟩)
  by_cases h24 : index < 100
  · have hshift : index - 96 + 96 = index := by omega
    simpa only [hshift] using
      (block0024_checked ⟨index - 96, by omega⟩)
  by_cases h25 : index < 104
  · have hshift : index - 100 + 100 = index := by omega
    simpa only [hshift] using
      (block0025_checked ⟨index - 100, by omega⟩)
  by_cases h26 : index < 108
  · have hshift : index - 104 + 104 = index := by omega
    simpa only [hshift] using
      (block0026_checked ⟨index - 104, by omega⟩)
  by_cases h27 : index < 112
  · have hshift : index - 108 + 108 = index := by omega
    simpa only [hshift] using
      (block0027_checked ⟨index - 108, by omega⟩)
  by_cases h28 : index < 116
  · have hshift : index - 112 + 112 = index := by omega
    simpa only [hshift] using
      (block0028_checked ⟨index - 112, by omega⟩)
  by_cases h29 : index < 120
  · have hshift : index - 116 + 116 = index := by omega
    simpa only [hshift] using
      (block0029_checked ⟨index - 116, by omega⟩)
  by_cases h30 : index < 124
  · have hshift : index - 120 + 120 = index := by omega
    simpa only [hshift] using
      (block0030_checked ⟨index - 120, by omega⟩)
  by_cases h31 : index < 128
  · have hshift : index - 124 + 124 = index := by omega
    simpa only [hshift] using
      (block0031_checked ⟨index - 124, by omega⟩)
  by_cases h32 : index < 132
  · have hshift : index - 128 + 128 = index := by omega
    simpa only [hshift] using
      (block0032_checked ⟨index - 128, by omega⟩)
  by_cases h33 : index < 136
  · have hshift : index - 132 + 132 = index := by omega
    simpa only [hshift] using
      (block0033_checked ⟨index - 132, by omega⟩)
  by_cases h34 : index < 140
  · have hshift : index - 136 + 136 = index := by omega
    simpa only [hshift] using
      (block0034_checked ⟨index - 136, by omega⟩)
  by_cases h35 : index < 144
  · have hshift : index - 140 + 140 = index := by omega
    simpa only [hshift] using
      (block0035_checked ⟨index - 140, by omega⟩)
  by_cases h36 : index < 148
  · have hshift : index - 144 + 144 = index := by omega
    simpa only [hshift] using
      (block0036_checked ⟨index - 144, by omega⟩)
  by_cases h37 : index < 152
  · have hshift : index - 148 + 148 = index := by omega
    simpa only [hshift] using
      (block0037_checked ⟨index - 148, by omega⟩)
  by_cases h38 : index < 156
  · have hshift : index - 152 + 152 = index := by omega
    simpa only [hshift] using
      (block0038_checked ⟨index - 152, by omega⟩)
  by_cases h39 : index < 160
  · have hshift : index - 156 + 156 = index := by omega
    simpa only [hshift] using
      (block0039_checked ⟨index - 156, by omega⟩)
  by_cases h40 : index < 164
  · have hshift : index - 160 + 160 = index := by omega
    simpa only [hshift] using
      (block0040_checked ⟨index - 160, by omega⟩)
  by_cases h41 : index < 168
  · have hshift : index - 164 + 164 = index := by omega
    simpa only [hshift] using
      (block0041_checked ⟨index - 164, by omega⟩)
  by_cases h42 : index < 172
  · have hshift : index - 168 + 168 = index := by omega
    simpa only [hshift] using
      (block0042_checked ⟨index - 168, by omega⟩)
  by_cases h43 : index < 176
  · have hshift : index - 172 + 172 = index := by omega
    simpa only [hshift] using
      (block0043_checked ⟨index - 172, by omega⟩)
  by_cases h44 : index < 180
  · have hshift : index - 176 + 176 = index := by omega
    simpa only [hshift] using
      (block0044_checked ⟨index - 176, by omega⟩)
  by_cases h45 : index < 184
  · have hshift : index - 180 + 180 = index := by omega
    simpa only [hshift] using
      (block0045_checked ⟨index - 180, by omega⟩)
  by_cases h46 : index < 188
  · have hshift : index - 184 + 184 = index := by omega
    simpa only [hshift] using
      (block0046_checked ⟨index - 184, by omega⟩)
  by_cases h47 : index < 192
  · have hshift : index - 188 + 188 = index := by omega
    simpa only [hshift] using
      (block0047_checked ⟨index - 188, by omega⟩)
  by_cases h48 : index < 196
  · have hshift : index - 192 + 192 = index := by omega
    simpa only [hshift] using
      (block0048_checked ⟨index - 192, by omega⟩)
  by_cases h49 : index < 200
  · have hshift : index - 196 + 196 = index := by omega
    simpa only [hshift] using
      (block0049_checked ⟨index - 196, by omega⟩)
  by_cases h50 : index < 204
  · have hshift : index - 200 + 200 = index := by omega
    simpa only [hshift] using
      (block0050_checked ⟨index - 200, by omega⟩)
  by_cases h51 : index < 208
  · have hshift : index - 204 + 204 = index := by omega
    simpa only [hshift] using
      (block0051_checked ⟨index - 204, by omega⟩)
  by_cases h52 : index < 212
  · have hshift : index - 208 + 208 = index := by omega
    simpa only [hshift] using
      (block0052_checked ⟨index - 208, by omega⟩)
  by_cases h53 : index < 216
  · have hshift : index - 212 + 212 = index := by omega
    simpa only [hshift] using
      (block0053_checked ⟨index - 212, by omega⟩)
  by_cases h54 : index < 220
  · have hshift : index - 216 + 216 = index := by omega
    simpa only [hshift] using
      (block0054_checked ⟨index - 216, by omega⟩)
  by_cases h55 : index < 224
  · have hshift : index - 220 + 220 = index := by omega
    simpa only [hshift] using
      (block0055_checked ⟨index - 220, by omega⟩)
  by_cases h56 : index < 228
  · have hshift : index - 224 + 224 = index := by omega
    simpa only [hshift] using
      (block0056_checked ⟨index - 224, by omega⟩)
  by_cases h57 : index < 232
  · have hshift : index - 228 + 228 = index := by omega
    simpa only [hshift] using
      (block0057_checked ⟨index - 228, by omega⟩)
  by_cases h58 : index < 236
  · have hshift : index - 232 + 232 = index := by omega
    simpa only [hshift] using
      (block0058_checked ⟨index - 232, by omega⟩)
  by_cases h59 : index < 240
  · have hshift : index - 236 + 236 = index := by omega
    simpa only [hshift] using
      (block0059_checked ⟨index - 236, by omega⟩)
  by_cases h60 : index < 244
  · have hshift : index - 240 + 240 = index := by omega
    simpa only [hshift] using
      (block0060_checked ⟨index - 240, by omega⟩)
  by_cases h61 : index < 248
  · have hshift : index - 244 + 244 = index := by omega
    simpa only [hshift] using
      (block0061_checked ⟨index - 244, by omega⟩)
  by_cases h62 : index < 252
  · have hshift : index - 248 + 248 = index := by omega
    simpa only [hshift] using
      (block0062_checked ⟨index - 248, by omega⟩)
  by_cases h63 : index < 256
  · have hshift : index - 252 + 252 = index := by omega
    simpa only [hshift] using
      (block0063_checked ⟨index - 252, by omega⟩)
  by_cases h64 : index < 260
  · have hshift : index - 256 + 256 = index := by omega
    simpa only [hshift] using
      (block0064_checked ⟨index - 256, by omega⟩)
  by_cases h65 : index < 264
  · have hshift : index - 260 + 260 = index := by omega
    simpa only [hshift] using
      (block0065_checked ⟨index - 260, by omega⟩)
  by_cases h66 : index < 268
  · have hshift : index - 264 + 264 = index := by omega
    simpa only [hshift] using
      (block0066_checked ⟨index - 264, by omega⟩)
  by_cases h67 : index < 272
  · have hshift : index - 268 + 268 = index := by omega
    simpa only [hshift] using
      (block0067_checked ⟨index - 268, by omega⟩)
  by_cases h68 : index < 276
  · have hshift : index - 272 + 272 = index := by omega
    simpa only [hshift] using
      (block0068_checked ⟨index - 272, by omega⟩)
  by_cases h69 : index < 280
  · have hshift : index - 276 + 276 = index := by omega
    simpa only [hshift] using
      (block0069_checked ⟨index - 276, by omega⟩)
  by_cases h70 : index < 284
  · have hshift : index - 280 + 280 = index := by omega
    simpa only [hshift] using
      (block0070_checked ⟨index - 280, by omega⟩)
  by_cases h71 : index < 288
  · have hshift : index - 284 + 284 = index := by omega
    simpa only [hshift] using
      (block0071_checked ⟨index - 284, by omega⟩)
  by_cases h72 : index < 292
  · have hshift : index - 288 + 288 = index := by omega
    simpa only [hshift] using
      (block0072_checked ⟨index - 288, by omega⟩)
  by_cases h73 : index < 296
  · have hshift : index - 292 + 292 = index := by omega
    simpa only [hshift] using
      (block0073_checked ⟨index - 292, by omega⟩)
  by_cases h74 : index < 300
  · have hshift : index - 296 + 296 = index := by omega
    simpa only [hshift] using
      (block0074_checked ⟨index - 296, by omega⟩)
  by_cases h75 : index < 304
  · have hshift : index - 300 + 300 = index := by omega
    simpa only [hshift] using
      (block0075_checked ⟨index - 300, by omega⟩)
  by_cases h76 : index < 308
  · have hshift : index - 304 + 304 = index := by omega
    simpa only [hshift] using
      (block0076_checked ⟨index - 304, by omega⟩)
  by_cases h77 : index < 312
  · have hshift : index - 308 + 308 = index := by omega
    simpa only [hshift] using
      (block0077_checked ⟨index - 308, by omega⟩)
  by_cases h78 : index < 316
  · have hshift : index - 312 + 312 = index := by omega
    simpa only [hshift] using
      (block0078_checked ⟨index - 312, by omega⟩)
  by_cases h79 : index < 320
  · have hshift : index - 316 + 316 = index := by omega
    simpa only [hshift] using
      (block0079_checked ⟨index - 316, by omega⟩)
  by_cases h80 : index < 324
  · have hshift : index - 320 + 320 = index := by omega
    simpa only [hshift] using
      (block0080_checked ⟨index - 320, by omega⟩)
  by_cases h81 : index < 328
  · have hshift : index - 324 + 324 = index := by omega
    simpa only [hshift] using
      (block0081_checked ⟨index - 324, by omega⟩)
  by_cases h82 : index < 332
  · have hshift : index - 328 + 328 = index := by omega
    simpa only [hshift] using
      (block0082_checked ⟨index - 328, by omega⟩)
  by_cases h83 : index < 336
  · have hshift : index - 332 + 332 = index := by omega
    simpa only [hshift] using
      (block0083_checked ⟨index - 332, by omega⟩)
  by_cases h84 : index < 340
  · have hshift : index - 336 + 336 = index := by omega
    simpa only [hshift] using
      (block0084_checked ⟨index - 336, by omega⟩)
  by_cases h85 : index < 344
  · have hshift : index - 340 + 340 = index := by omega
    simpa only [hshift] using
      (block0085_checked ⟨index - 340, by omega⟩)
  by_cases h86 : index < 348
  · have hshift : index - 344 + 344 = index := by omega
    simpa only [hshift] using
      (block0086_checked ⟨index - 344, by omega⟩)
  by_cases h87 : index < 352
  · have hshift : index - 348 + 348 = index := by omega
    simpa only [hshift] using
      (block0087_checked ⟨index - 348, by omega⟩)
  by_cases h88 : index < 356
  · have hshift : index - 352 + 352 = index := by omega
    simpa only [hshift] using
      (block0088_checked ⟨index - 352, by omega⟩)
  by_cases h89 : index < 360
  · have hshift : index - 356 + 356 = index := by omega
    simpa only [hshift] using
      (block0089_checked ⟨index - 356, by omega⟩)
  by_cases h90 : index < 364
  · have hshift : index - 360 + 360 = index := by omega
    simpa only [hshift] using
      (block0090_checked ⟨index - 360, by omega⟩)
  by_cases h91 : index < 368
  · have hshift : index - 364 + 364 = index := by omega
    simpa only [hshift] using
      (block0091_checked ⟨index - 364, by omega⟩)
  by_cases h92 : index < 372
  · have hshift : index - 368 + 368 = index := by omega
    simpa only [hshift] using
      (block0092_checked ⟨index - 368, by omega⟩)
  by_cases h93 : index < 376
  · have hshift : index - 372 + 372 = index := by omega
    simpa only [hshift] using
      (block0093_checked ⟨index - 372, by omega⟩)
  by_cases h94 : index < 380
  · have hshift : index - 376 + 376 = index := by omega
    simpa only [hshift] using
      (block0094_checked ⟨index - 376, by omega⟩)
  by_cases h95 : index < 384
  · have hshift : index - 380 + 380 = index := by omega
    simpa only [hshift] using
      (block0095_checked ⟨index - 380, by omega⟩)
  by_cases h96 : index < 388
  · have hshift : index - 384 + 384 = index := by omega
    simpa only [hshift] using
      (block0096_checked ⟨index - 384, by omega⟩)
  by_cases h97 : index < 392
  · have hshift : index - 388 + 388 = index := by omega
    simpa only [hshift] using
      (block0097_checked ⟨index - 388, by omega⟩)
  by_cases h98 : index < 396
  · have hshift : index - 392 + 392 = index := by omega
    simpa only [hshift] using
      (block0098_checked ⟨index - 392, by omega⟩)
  by_cases h99 : index < 400
  · have hshift : index - 396 + 396 = index := by omega
    simpa only [hshift] using
      (block0099_checked ⟨index - 396, by omega⟩)
  by_cases h100 : index < 404
  · have hshift : index - 400 + 400 = index := by omega
    simpa only [hshift] using
      (block0100_checked ⟨index - 400, by omega⟩)
  by_cases h101 : index < 408
  · have hshift : index - 404 + 404 = index := by omega
    simpa only [hshift] using
      (block0101_checked ⟨index - 404, by omega⟩)
  by_cases h102 : index < 412
  · have hshift : index - 408 + 408 = index := by omega
    simpa only [hshift] using
      (block0102_checked ⟨index - 408, by omega⟩)
  by_cases h103 : index < 416
  · have hshift : index - 412 + 412 = index := by omega
    simpa only [hshift] using
      (block0103_checked ⟨index - 412, by omega⟩)
  have hshift : index - 416 + 416 = index := by omega
  simpa only [hshift] using
    (block0104_checked ⟨index - 416, by omega⟩)

theorem all_frames_checked (index : ℕ) (hi : index < 419) :
    SupportSearch.Bits.Cuts.Frame.Checked coverMask compatibleMask terminal lookup (frames index) :=
  SupportSearch.Bits.Cuts.table_sound coverMask compatibleMask terminal lookup frames fragments
    419 31 table_checks index hi

theorem root_frame_eq : frames 418 = rootFrame := by
  decide +kernel

theorem root_tape_checked :
    SupportSearch.Bits.tapeCheck coverMask compatibleMask terminal lookup 127 11334
      18 42535295865059279493580323728585125600 332306998946226607078739122971475968 5 = true := by
  have h := all_frames_checked 418 (by decide)
  rw [root_frame_eq] at h
  exact h

theorem tape_checked :
    SupportSearch.Bits.tapeCheck (InitialMemo.cover 8 251 coverTable)
      (InitialMemo.compatible 251 inverse 126 compatibleTable 4)
      terminal lookup 127 11334
      (InitialBits.encode (InitialSupport.selected 4))
      (InitialBits.encode (InitialSupport.available 251 inverse 4))
      (InitialBits.encode (InitialSupport.uncovered 8 251 4)) 5 = true := by
  rw [selected_mask_checked, available_mask_checked, uncovered_mask_checked]
  exact root_tape_checked

theorem root_checked :
    SupportSearch.check (InitialSupport.badTimes 8 251)
      (InitialSupport.pairCompatible 251 inverse 4) terminal tree
      (InitialSupport.selected 4) (InitialSupport.available 251 inverse 4)
      (InitialSupport.uncovered 8 251 4) 5 = true := by
  exact InitialMemo.checked_tree 8 251 inverse 126 (by decide)
    coverTable compatibleTable cover_checked compatible_checked 4
    terminal lookup 127 11334 5 tape_checked

end Loneliness.Modular.SupportLists.N07D08P0251.Cut031.B0004
