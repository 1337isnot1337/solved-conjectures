#!/usr/bin/env python3
"""Actual Lean extraction fixtures for the new raw-occurrence audit.

This is a development diagnostic. Intentional foreign axioms occur only in
isolated negative fixtures. Their objects are never accepted project inputs.
Negative fixtures execute the unchanged raw-graph command before the base
command, so an earlier collected-axiom rejection cannot mask missing raw-body
extraction. Positive fixtures use the production command order.
"""
from pathlib import Path
import hashlib,json,os,sys

BASE=Path('/workspace/scratch/0fcb948242df')
CANDIDATE=BASE/'prime_work/frankl-final-raw-graph-candidate'
BASE_AUDITORS=BASE/'prime_work/modular-cover-byte-counts-hosted/controls/scripts'
sys.path[:0]=[str(CANDIDATE/'scripts'),str(BASE_AUDITORS)]
import audit_lean_owned_extension as extension
import audit_lean_all_owned as all_owned
import audit_lean_raw_occurrences as raw
import verify_frankl_span_four_final as gate

STAGE=BASE/'prime_work/raw-occurrence-helper-probe/real-fixtures'
RUNTIME=json.loads((BASE/'lean-runtime.json').read_text())
COMPILER=RUNTIME['compiler']+'/bin/lean'
HELPER_HASH=hashlib.sha256(Path(raw.__file__).read_bytes()).hexdigest()
HASH=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
BAD='''module
public axiom RawFixture.bad : True
public theorem RawFixture.unusedBad : True := RawFixture.bad
'''
SAFE='True.intro'
OTHER='(fun h : True => h) True.intro'
UNSAFE='RawFixture.bad'
CASES=[]
for label,left,right,expected in [
 ('safe_distinct',OTHER,SAFE,'pass'),
 ('bad_late',SAFE,UNSAFE,'reject'),
 ('bad_early',UNSAFE,SAFE,'reject')]:
 files={'Foreign.RawFixtureBad':BAD}
 modules=['Conjectures.RawFixtureA','Conjectures.RawFixtureB']
 for module,proof in zip(modules,[left,right]):
  files[module]='module\nimport Foreign.RawFixtureBad\npublic theorem RawFixture.target : True := '+proof+'\n'
 CASES.append(dict(name=label,files=files,modules=modules,modern={m:True for m in modules},
                   expected=expected,flavor='extension',required='RawFixture.target'))
for label,left,right in [('foreign_bad_late',SAFE,UNSAFE),('foreign_bad_early',UNSAFE,SAFE)]:
 files={'Foreign.RawFixtureBad':BAD}
 for module,proof in [('Foreign.RawFixtureHelperA',left),('Foreign.RawFixtureHelperB',right)]:
  files[module]='module\nimport Foreign.RawFixtureBad\npublic theorem RawFixture.helper : True := '+proof+'\n'
 module='Conjectures.RawFixtureRoot'
 files[module]='''module
import Foreign.RawFixtureHelperA
import Foreign.RawFixtureHelperB
public theorem RawFixture.target : True := RawFixture.helper
'''
 CASES.append(dict(name=label,files=files,modules=[module],modern={module:True},
                   expected='reject',flavor='extension',required='RawFixture.target'))
module='Conjectures.RawFixtureLegacy'
CASES.append(dict(name='legacy_safe',files={module:'theorem FixtureLegacy.target : True := True.intro\n'},
                  modules=[module],modern={module:False},expected='pass',flavor='all_owned',
                  required='FixtureLegacy.target',prefixes=['FixtureLegacy.']))
modern='Conjectures.RawFixtureModern'
legacy='Conjectures.RawFixtureLegacy'
CASES.append(dict(name='mixed_safe',files={
 modern:'module\npublic theorem FixtureMixed.modern : True := True.intro\n',
 legacy:'theorem FixtureMixed.legacy : True := True.intro\n'},
 modules=[modern,legacy],modern={modern:True,legacy:False},expected='pass',
 flavor='all_owned',required='FixtureMixed.modern',prefixes=['FixtureMixed.']))

def raw_first(source):
 anchor='open Lean Elab Command in\nrun_cmd do\n'
 base_start=source.index(anchor)
 raw_start=source.index('private structure RawOccurrenceVariant where')
 assert base_start<raw_start
 return source[:base_start]+source[raw_start:]+'\n'+source[base_start:raw_start]

def run_case(case):
 stage=STAGE/case['name']
 stage.mkdir(parents=True,exist_ok=False)
 src=stage/'src';lib=stage/'lib/lean';src.mkdir();lib.mkdir(parents=True)
 env={**os.environ,'LEAN_PATH':str(lib),'LEAN_SYSROOT':RUNTIME['compiler'],
      'LEAN_NUM_THREADS':'1','UV_USE_IO_URING':'0'}
 frozen={}
 result={k:v for k,v in case.items() if k!='files'}
 result.update(status='pending',source_checks=[],source_sha256={},helper_sha256=HELPER_HASH,
               raw_command_first=case['expected']=='reject',diagnostic_only=True)
 def save():
  (stage/'result.json').write_bytes(gate.encoded(result))
 for module,contents in case['files'].items():
  relative=Path(module.replace('.','/')+'.lean')
  path=src/relative;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(contents)
  frozen[path]=HASH(path);result['source_sha256'][module]=frozen[path]
  target=lib/relative.with_suffix('.olean');target.parent.mkdir(parents=True,exist_ok=True)
  command=[COMPILER,'-j1','-M3072','-DwarningAsError=true','-t0','-o',str(target),str(relative)]
  check=gate.orbit.profile(command,src,env,stage/(module+'.source.log'),stage/(module+'.source-progress.json'),120)
  result['source_checks'].append({'module':module,**check});save()
  if check['exit_code']!=0 or check['timed_out']:
   result['status']='fixture_source_failed';save();return result
  for path in target.parent.glob(target.stem+'.*'):
   if path.is_file():frozen[path]=HASH(path)
 if case['flavor']=='extension':
  required={module:[] for module in case['modules']}
  required[case['modules'][0]]=[case['required']]
  source=raw.augment_source(extension.audit_source(case['modules'],case['modules'],required),
                           case['modules'],case['modern'],flavor='extension')
 else:
  spec={'modules':case['modules'],'required':[case['required']],'legacy_prefixes':case['prefixes']}
  source=raw.augment_source(all_owned.audit_source(**spec),case['modules'],case['modern'],
                           flavor='all_owned',legacy_prefixes=case['prefixes'])
 if case['expected']=='reject':source=raw_first(source)
 audit=src/'Audit.lean';audit.write_text(source);frozen[audit]=HASH(audit)
 result['audit_source_sha256']=frozen[audit]
 (stage/'frozen-inputs.json').write_bytes(gate.encoded({str(p.relative_to(stage)):d for p,d in frozen.items()}))
 check=gate.orbit.profile([COMPILER,'-j1','-M3072','-DwarningAsError=true','-t0','Audit.lean'],
                         src,env,stage/'audit.log',stage/'audit-progress.json',300)
 result['audit_profile']=check
 text=(stage/'audit.log').read_text()
 if case['expected']=='pass':
  if check['exit_code']==0 and not check['timed_out']:
   try:
    if case['flavor']=='extension':
     inventory=raw.validate_extension_log(text,case['modules'],case['modules'],required)
    else:inventory=raw.validate_all_owned_log(text,spec,case['modern'])
    graph=inventory['raw_occurrence_graph']
    if case['name']=='safe_distinct':
     assert graph['summary']['selected_kernel_checks']>=1
     assert graph['summary']['kernel_checks']>=2
     assert all(node['name']!='RawFixture.bad' for node in graph['nodes'].values())
    result.update(status='passed',raw_graph_summary=graph['summary'])
    (stage/'inventory.json').write_bytes(gate.encoded(inventory))
   except Exception as error:result.update(status='validation_failed',error=str(error))
  else:result['status']='unexpected_audit_failure'
 else:
  reached='Unapproved raw dependency axiom: RawFixture.bad'
  result['status']='passed' if check['exit_code']!=0 and not check['timed_out'] and reached in text else 'wrong_or_missing_rejection'
  result['required_rejection']=reached
  result['actual_extractor_rejected']=reached in text
 assert HASH(Path(raw.__file__))==HELPER_HASH
 for path,digest in frozen.items():assert HASH(path)==digest,str(path)
 result['all_inputs_unchanged']=True;save()
 print(json.dumps({'case':case['name'],'status':result['status'],
                   'seconds':check['seconds'],'peak_rss_kib':check['peak_rss_kib']}),flush=True)
 return result

def main():
 STAGE.mkdir(parents=True,exist_ok=False)
 summary={'status':'pending','helper_sha256':HELPER_HASH,'cases':[],'diagnostic_only':True}
 for case in CASES:
  result=run_case(case);summary['cases'].append({'name':case['name'],'status':result['status']})
  (STAGE/'summary.json').write_bytes(gate.encoded(summary))
  if result['status']!='passed':break
 summary['status']='passed' if len(summary['cases'])==len(CASES) and all(r['status']=='passed' for r in summary['cases']) else 'failed'
 (STAGE/'summary.json').write_bytes(gate.encoded(summary))
 print(json.dumps(summary,sort_keys=True),flush=True)

if __name__=='__main__':main()

