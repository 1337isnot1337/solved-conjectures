from pathlib import Path
import json,sys,os,hashlib
base=Path('/workspace/scratch/0fcb948242df')
candidate=base/'prime_work/frankl-final-raw-graph-candidate'
auditors=base/'prime_work/modular-cover-byte-counts-hosted/controls/scripts'
sys.path[:0]=[str(candidate/'scripts'),str(auditors)]
import audit_lean_all_owned as old
import audit_lean_raw_occurrences as raw
import verify_frankl_span_four_final as gate
runtime=json.loads((base/'lean-runtime.json').read_text())
origin=base/'prime_work/raw-occurrence-helper-probe/real-fixtures/legacy_safe'
stage=base/'prime_work/raw-occurrence-helper-probe/legacy-default-options'
stage.mkdir(exist_ok=False)
module='Conjectures.RawFixtureLegacy'
spec={'modules':[module],'required':['FixtureLegacy.target'],'legacy_prefixes':['FixtureLegacy']}
modern={module:False}
text=old.audit_source(**spec)
pair='set_option maxRecDepth 100000\nset_option maxHeartbeats 0\n'
assert text.count(pair)==1
source=raw.augment_source(text.replace(pair,''),[module],modern,flavor='all_owned',legacy_prefixes=spec['legacy_prefixes'])
(stage/'Audit.lean').write_text(source)
frozen={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [
 Path(raw.__file__),Path(old.__file__),stage/'Audit.lean',
 origin/'src/Conjectures/RawFixtureLegacy.lean',origin/'lib/lean/Conjectures/RawFixtureLegacy.olean']}
(stage/'frozen-inputs.json').write_bytes(gate.encoded(frozen))
env={**os.environ,'LEAN_PATH':str(origin/'lib/lean'),'LEAN_SYSROOT':runtime['compiler'],
 'LEAN_NUM_THREADS':'1','UV_USE_IO_URING':'0'}
profile=gate.orbit.profile([runtime['compiler']+'/bin/lean','-j1','-M3072','-DwarningAsError=true','-t0','Audit.lean'],
 stage,env,stage/'audit.log',stage/'progress.json',300)
result={'status':'failed','profile':profile,'base_resource_options_removed':True,'legacy_prefixes':spec['legacy_prefixes'],
 'helper_sha256':frozen[str(Path(raw.__file__))],'diagnostic_only':True}
if profile['exit_code']==0 and not profile['timed_out']:
 try:
  inventory=raw.validate_all_owned_log((stage/'audit.log').read_text(),spec,modern)
  (stage/'inventory.json').write_bytes(gate.encoded(inventory))
  result.update(status='development_audit_passed',raw_graph_summary=inventory['raw_occurrence_graph']['summary'])
 except Exception as error:result['validation_error']=str(error)
for name,digest in frozen.items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
result['all_frozen_inputs_unchanged']=True
(stage/'result.json').write_bytes(gate.encoded(result))
print(json.dumps(result,sort_keys=True),flush=True)
if result['status']=='failed':
 print('\n'.join(line for line in (stage/'audit.log').read_text().splitlines() if 'error:' in line),flush=True)

