from pathlib import Path
import json,os,sys,hashlib
base=Path('/workspace/scratch/0fcb948242df')
candidate=base/'prime_work/frankl-final-raw-graph-candidate'
sys.path.insert(0,str(candidate/'scripts'))
import verify_frankl_span_four_final as gate
import audit_lean_raw_occurrences as raw
stage=base/'prime_work/raw-occurrence-helper-probe/modern-attempt06'
objects=base/'prime_work/frankl-final-occurrence-audit'
manifest=json.loads((stage/'manifest.json').read_text())
runtime=json.loads((base/'lean-runtime.json').read_text())
full_frozen=json.loads((objects/'frozen-inputs.json').read_text())
names=set()
for module in manifest['modules']:
 stem=module.replace('.','/')
 names.add('src/'+stem+'.lean')
 for suffix in ('.olean','.olean.private','.olean.server','.ir','.ir.sig'):
  path='lib/lean/'+stem+suffix
  if path in full_frozen:names.add(path)
frozen={name:full_frozen[name] for name in sorted(names)}
def verify_inputs():
 assert hashlib.sha256((stage/'ModernRawAudit.lean').read_bytes()).hexdigest()==manifest['source_sha256']
 assert hashlib.sha256((candidate/'scripts/audit_lean_raw_occurrences.py').read_bytes()).hexdigest()==manifest['helper_sha256']
 for name,digest in frozen.items():
  assert hashlib.sha256((objects/name).read_bytes()).hexdigest()==digest,name
verify_inputs()
(stage/'frozen-project-inputs.json').write_bytes(gate.encoded(frozen))
env={**os.environ,'LEAN_PATH':os.pathsep.join([str(objects/'lib/lean'),*runtime['external']]),
 'LEAN_SYSROOT':runtime['compiler'],'LEAN_NUM_THREADS':'1','UV_USE_IO_URING':'0'}
command=[runtime['compiler']+'/bin/lean','-j1','-M3072','-DwarningAsError=true','-t0','ModernRawAudit.lean']
check=gate.orbit.profile(command,stage,env,stage/'audit.log',stage/'progress.json',300)
result={'status':'failed','profile':check,'project_modules':len(manifest['modules']),
 'source_sha256':manifest['source_sha256'],'helper_sha256':manifest['helper_sha256'],
 'frozen_project_inputs':len(frozen),'diagnostic_only':True}
if check['exit_code']==0 and not check['timed_out']:
 try:
  details=raw.validate_extension_log((stage/'audit.log').read_text(),manifest['modules'],manifest['modules'],manifest['required_by_module'])
  (stage/'inventory.json').write_bytes(gate.encoded(details))
  result.update(status='development_audit_passed',summary=details['summary'],
                raw_graph_summary=details['raw_occurrence_graph']['summary'])
 except Exception as error:result['validation_error']=str(error)
verify_inputs()
result['all_frozen_inputs_unchanged']=True
(stage/'result.json').write_bytes(gate.encoded(result))
print(json.dumps(result,sort_keys=True),flush=True)
if result['status']=='failed':
 lines=[line for line in (stage/'audit.log').read_text().splitlines() if 'error:' in line or ': error(' in line]
 print('\n'.join(lines[-20:]),flush=True)

