module
import all Conjectures.FranklSpanFourGraphMasks
import all Conjectures.FranklSpanFourGraphWords
public meta import Lean.Elab.Command
import Lean.Data.Json
import Lean.Util.FoldConsts

set_option maxRecDepth 100000
set_option maxHeartbeats 0

open Lean Elab Command in
run_cmd do
  let env := (← getEnv).setExporting false
  let options ← getOptions
  let kernel := env.toKernelEnv
  unless kernel.header.trustLevel == 0 do
    throwError "Raw proof checks require the process to use trust level zero"
  let target := `FranklSpanFour.Graph.wordOfCode.eq_def
  let some visible := kernel.find? target | throwError "Target is absent"
  let some ownerIndex := env.getModuleIdxFor? target | throwError "Owner is absent"
  let owner := env.header.modules[ownerIndex]!.module
  let requested : Array Name :=
    #[`Conjectures.FranklSpanFourGraphMasks, `Conjectures.FranklSpanFourGraphWords]
  let mut copies : Array (Name × ConstantInfo) := #[]
  for moduleName in requested do
    let some index := env.header.modules.findIdx? (fun item => item.module == moduleName)
      | throwError "Requested module absent"
    let data := env.header.moduleData[index]!
    unless data.constNames == data.constants.map (·.name) do
      throwError "Raw inventory differs"
    let some info := data.constants.find? (fun item => item.name == target)
      | throwError "Raw target absent"
    copies := copies.push (moduleName, info)
    let .thmInfo raw := info | throwError "Raw target is not a theorem"
    let fresh := Name.num `FranklRawEquationProbe copies.size
    unless (kernel.find? fresh).isNone do throwError "Alias is not fresh"
    let renamedTheorem := { raw with name := fresh }
    let checked ← match kernel.addDeclCore (Core.getMaxHeartbeats options).toUSize
        (maxRecDepth.get options).toUSize (.thmDecl renamedTheorem) none with
      | .ok result => pure result
      | .error error => throwError "Raw theorem kernel check failed: {error.toMessageData options}"
    unless checked.find? fresh == some (.thmInfo renamedTheorem) do
      throwError "Kernel alias changed the supplied ConstantInfo"
    unless (kernel.find? fresh).isNone do throwError "Original kernel environment changed"
    let record := Json.mkObj [
      ("tag", toJson "checked_copy"), ("module", toJson moduleName.toString),
      ("owner", toJson owner.toString), ("visible_equal", toJson (info == visible)),
      ("level_params", toJson (info.levelParams.map (·.toString))),
      ("type_equal", toJson (info.type == visible.type)),
      ("value_equal", toJson (info.value? true == visible.value? true)),
      ("kernel_alias", toJson fresh.toString), ("kernel_passed", toJson true),
      ("alias_exact", toJson true), ("kernel_trust_level", toJson kernel.header.trustLevel.toNat)]
    logInfo m!"EQUATION-ENVIRONMENT-DIAGNOSTIC {record.compress}"
  let left := copies[0]!.2
  let right := copies[1]!.2
  let some leftValue := left.value? true | throwError "Left proof absent"
  let some rightValue := right.value? true | throwError "Right proof absent"
  let leftNames := leftValue.getUsedConstantsAsSet
  let rightNames := rightValue.getUsedConstantsAsSet
  let leftOnly := leftNames.toArray.filter (fun name => !rightNames.contains name)
  let rightOnly := rightNames.toArray.filter (fun name => !leftNames.contains name)
  unless leftOnly.size == 1 && rightOnly.size == 1 do
    throwError "Unexpected private dependency difference"
  let renamed := leftValue.replace fun expression => match expression with
    | .const name levels =>
        if name == leftOnly[0]! then some (.const rightOnly[0]! levels) else none
    | _ => none
  unless renamed == rightValue do
    throwError "Proof values differ beyond the private splitter name"
  let badName := `FranklRawEquationProbe.invalid
  unless (kernel.find? badName).isNone do throwError "Negative-control alias is not fresh"
  let bad : TheoremVal := {
    name := badName
    levelParams := []
    type := mkConst `False
    value := mkConst `True.intro
    all := [badName]
  }
  match kernel.addDeclCore (Core.getMaxHeartbeats options).toUSize
      (maxRecDepth.get options).toUSize (.thmDecl bad) none with
    | .ok _ => throwError "Checked kernel accepted ill-typed negative control"
    | .error _ => pure ()
  let record := Json.mkObj [
    ("tag", toJson "complete"), ("owner", toJson owner.toString),
    ("left_private_dependency", toJson leftOnly[0]!.toString),
    ("right_private_dependency", toJson rightOnly[0]!.toString),
    ("proof_equal_after_exact_constant_rename", toJson true),
    ("all_raw_copies_kernel_checked", toJson true),
    ("ill_typed_kernel_negative_control_rejected", toJson true)]
  logInfo m!"EQUATION-ENVIRONMENT-DIAGNOSTIC {record.compress}"

