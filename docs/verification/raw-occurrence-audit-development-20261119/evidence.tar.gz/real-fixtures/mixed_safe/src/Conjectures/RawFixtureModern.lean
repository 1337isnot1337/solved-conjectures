module
public theorem FixtureMixed.modern : True := True.intro
