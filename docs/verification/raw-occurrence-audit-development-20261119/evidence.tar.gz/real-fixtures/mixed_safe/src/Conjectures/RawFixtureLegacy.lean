theorem FixtureMixed.legacy : True := True.intro
