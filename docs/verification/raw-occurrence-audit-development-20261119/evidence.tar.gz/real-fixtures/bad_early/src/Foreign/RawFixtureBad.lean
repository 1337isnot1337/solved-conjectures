module
public axiom RawFixture.bad : True
public theorem RawFixture.unusedBad : True := RawFixture.bad
