module
import Foreign.RawFixtureBad
public theorem RawFixture.target : True := True.intro
