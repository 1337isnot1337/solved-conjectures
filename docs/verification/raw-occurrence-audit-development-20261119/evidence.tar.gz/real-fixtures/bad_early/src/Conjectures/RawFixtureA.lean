module
import Foreign.RawFixtureBad
public theorem RawFixture.target : True := RawFixture.bad
