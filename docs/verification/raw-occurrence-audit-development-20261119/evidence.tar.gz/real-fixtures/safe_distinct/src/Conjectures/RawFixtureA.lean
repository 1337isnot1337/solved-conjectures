module
import Foreign.RawFixtureBad
public theorem RawFixture.target : True := (fun h : True => h) True.intro
