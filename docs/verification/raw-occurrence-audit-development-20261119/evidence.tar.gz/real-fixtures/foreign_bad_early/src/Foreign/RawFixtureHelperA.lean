module
import Foreign.RawFixtureBad
public theorem RawFixture.helper : True := RawFixture.bad
