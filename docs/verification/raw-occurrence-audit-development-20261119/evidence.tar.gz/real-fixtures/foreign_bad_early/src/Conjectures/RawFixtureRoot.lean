module
import Foreign.RawFixtureHelperA
import Foreign.RawFixtureHelperB
public theorem RawFixture.target : True := RawFixture.helper
