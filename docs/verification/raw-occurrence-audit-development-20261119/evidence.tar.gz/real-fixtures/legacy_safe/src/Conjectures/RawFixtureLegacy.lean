theorem FixtureLegacy.target : True := True.intro
